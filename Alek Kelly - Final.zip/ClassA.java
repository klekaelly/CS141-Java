package Final;

/*  B  */
/**
 * 
 * @author Your Name here!
 *
 */
public class ClassA {

	private int first;
	private double second;
	
	public ClassA()
	{
		first = 0;
		second = 0.0;
	}
	
	public ClassA(int f, double s)
	{
		first = f;
		second = s;
	}
	
	public void set(int f, double s)
	{
		first = f;
		second = s;
	}
	
	public boolean equals(ClassA obj)
	{
		return this.first==obj.first && this.second==obj.second; 
	}
	
	@Override
	public String toString()
	{
		return "{"+first+"; "+second+"}";
	}
}
