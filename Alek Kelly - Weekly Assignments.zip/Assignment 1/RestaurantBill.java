// Imports
import java.util.Scanner;
import java.math.RoundingMode;
import java.text.DecimalFormat;

/**
 *
 * @author Alek Kelly
 * 
 */

//Class Declaration
public class RestaurantBill 
{
    //Static taxrate variable initialized
    static final double TAXRATE = 0.1;

    //Main Method Declaration
    public static void main(String[] args) 
    {

        /****** Variable Declarations and Scanner Initialization ******/

        // Creates scanner object to read patron input
        Scanner patronInput = new Scanner(System.in);

        // Variable declaration to hold user inputs
        double tipPercentage; //Holds the desired tip percentage from the user
        double billAmount;    //Holds the bill amount inputted by the user before tax/tip

        //Variable declarations to hold calculated amounts
        double totalCost;       //Holds the calculated totalCost of the meal with tax and tip
        double tipAmount;       //Holds the calculated tip Amount based upon the bill + tax
        double taxAmount;       //Holds the tax amount based upon the bill without tax
        double taxAndBill;      //Hold the bill amount with tax
        String taxAndBillForm;  // A formatted/printable version of tax + bill to represent real currency
        String tipAmountForm;   // A formatted/printable version of tipAmount
        String totalCostForm;   // A formatted/printable version of totalCost

        /****** Receiving User Input ******/

        // Assigns user response as the value of billAmount
        System.out.println("What is the bill amount?");
        billAmount = patronInput.nextDouble();

        //Assigns user response as the value of tipPercentage
        System.out.println("What is the tip percentage you would like to leave?");
        tipPercentage = patronInput.nextDouble();
        tipPercentage = convertPercDec(tipPercentage);  //Converts the inputted tip percentage into a decimal


        /****** Calling methods to compute values for the different variables ******/

        // Assigns a calculated value to these three variables
        taxAmount = calculateTipTax(TAXRATE, billAmount);               // Uses calculateTipTax to multiply the static taxrate by the bill amount inputted by the user
        taxAndBill = taxAmount + billAmount;                            // Adds the calculated taxAmount to the bill amount, taxAmount is stored separately due to the requirements of the problem
        tipAmount = calculateTipTax     (tipPercentage , taxAndBill);   // Uses calculateTipTax (Hence, the double name) to multiply the desired tip percentage by the amount of the bill after tax
        totalCost = calculateTotalBill  (tipAmount , taxAndBill);       // Calculates the total cost of the meal by adding the tip amount to the tax and bill
       
        taxAndBillForm = formatCurrency(taxAndBill);                                    // Formats the taxAndBill to appear as real currency would
        tipAmountForm = formatCurrency(tipAmount);                                      // Formats the tipAmount to appear as real currency would
        totalCostForm = formatCurrency(totalCost);                                      // Formats the totalCost to appear as real currency would
       

        /****** Printing out the results for the user to see ******/

        // Prints the bill with tax
        System.out.println("The cost of your meal including tax is  $" + taxAndBillForm);

        // Prints the value of your tip
        System.out.println("Your tip would be                       $" + tipAmountForm);

        // Prints the bill with tax and tip
        System.out.println("Your total bill would be                $" + totalCostForm);

        
        //Closes the patron scanner to prevent memory leak
        patronInput.close();

    }


    /****** Methods used to calculate and format different variables ******/

    // Method responsible for calculating the Tip and Tax
    public static double calculateTipTax(double x, double y) 
    {
        return x * y;
    }

    // Method responsible for calculating total bill (including Tip)
    public static double calculateTotalBill(double x, double y) 
    {
        return x + y;
    }

    // Converts values from decimals to percentages allowing for user to enter the
    // percentage and not worry about converting to decimal
    public static double convertDecPerc(double x) 
    {
        return x * 100;
    }

    // Converts values from percentages to decimals to reverse the process
    public static double convertPercDec(double x) 
    {
        return x / 100;
    }
    // Creates a decimal format string to define the total amount output in terms of real currency. This method always rounds up (You can't have half a cent..)
    public static String formatCurrency(double x) 
    {
        DecimalFormat df = new DecimalFormat(".##");
        df.setRoundingMode(RoundingMode.UP);

        return df.format(x);
    }
}