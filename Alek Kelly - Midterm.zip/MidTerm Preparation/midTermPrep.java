import java.io.*;
import java.util.Scanner;


public class midTermPrep {
    
    public static void main(String args[]) throws IOException
    {

        /**** Write a method that calculates and returns area of rectangle. Must check for positive inputs and throw illegalArgumentException if input is negative. Add code to header that announces the throw ****/
        double length = 5.6;
        double width = 4.5;

        System.out.println(calculateRectangleArea(length, width));



        /**** Generate 50 pairs of Random integers between [1, 100] and calculate 50 areas of a rectangle, passing the pair of numbers into the method, and print using Java formatting ****/
        
        //Repeat this 50 times for 50 pairs
        for(int i = 1; i <= 50; i++)
        {
            //Get two random values between 1
            length = Math.random() * 100;
            width = Math.random() * 100;

            System.out.println(i);
        }




        /**** Echo print a file ****/

        //Create the name of the file
        String fileName = "myList.txt";

        echoPrintFile(fileName);














    }

    /**
     * Method calculateRectangleArea validates input and returns the area of a
     * rectangle
     * 
     * @param length is the length of the rectangle (double)
     * @param width  is the width of the rectangle (double)
     * @throws IllegalArgumentException
     * @return Area of Rectangle (double)
     */
    public static double calculateRectangleArea(double length, double width)
    {
       
            if (length < 0)
            {
                throw new IllegalArgumentException("The value of length cannot be less than 0!");
            } 
            else if (width < 0)
            {
                throw new IllegalArgumentException("The value of width cannot be less than 0!");
                
            } else {
                return length * width;
            }

    }


    /**
     * Method calculateRectangleArea validates input and returns the area of a
     * rectangle
     * 
     * @param length is the length of the rectangle (double)
     * @throws FileNotFoundException
     * @throws IOException
     * 
     */

    public static void echoPrintFile(String fileName) throws IOException
    {
        

        int sum = 0;
       

        try
        {

        File myFile = new File (fileName);
        Scanner inputFile = new Scanner(myFile);

            while (inputFile.hasNextLine())
            {
                int number = inputFile.nextInt();
                System.out.println(number);

                sum = sum + number;
            }

        } catch (IOException  e)

        {
            throw new IOException("An IO Exception occured!");

        }

        System.out.println("The sum of the numbers is " + sum);

    }   

}
