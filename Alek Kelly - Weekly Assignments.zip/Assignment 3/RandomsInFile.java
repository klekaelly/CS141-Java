
/*
    For some reason, when using the same imports as your FileIO.java sheet, the "package fileio" wouldn't work. This
    resulted in my having to import each of these items individually.
*/

import java.util.Scanner; //Scanner class
import java.io.IOException; //Import to handle exception errors
import java.io.PrintWriter; //Importing PrintWriter
import java.io.File; //File class


/**
 *
 * @author Alek Kelly & Alexandra Vaschillo
 */

public class RandomsInFile {

    public static void main(String[] args) 
    {

    /*** Variable Declarations ***/

        String fileName;        // Holds the file name
        int numTimes = 100;     // The number of random numbers specified corresponds to the number of times output is needed
        int rangeValue1 = 0;        // Holds the input of the user until it is converted into an integer range
        int rangeValue2 = 0;        // Holds the input of the user until it is converted into an integer range
        String formatting;      // Used temporarily to format the user input


    /*** Getting the File Name ***/

        // Create a Scanner object for user input.
        Scanner userInput = new Scanner(System.in);

        // Get the filename from the user
        System.out.print("Enter a filename to write into: ");
        fileName = userInput.nextLine();

        // Creating and checking if the file already exists.
        File file = new File(fileName);
        if (file.exists())
        {
        System.out.println("The file " + fileName + " already exists. The content will be re-written.");
        }


    /*** Getting the Range from the User ***/ 

        // Get the user's input for value 1 of the range
        boolean again = true;
        while (again) 
        {
            System.out.print("Enter the first value of the range please: ");
            formatting = userInput.nextLine();
            formatting = formatting.trim();
            try 
            {
                rangeValue1 = Integer.parseInt(formatting); //Possible exception may occur here, which is what will be "caught" by the following catch block
                again = false;

            } 
            catch (Exception e) 
            {
                System.out.println("INPUT ERROR: Please enter an integer number!");
                System.out.println(e.getMessage());
            }
        }

        // Get the user's input for value 2 of the range
        again = true;
        while (again) 
        {
            System.out.print("Enter the second value of the range please: ");
            formatting = userInput.nextLine();
            formatting = formatting.trim();
            try 
            {
                rangeValue2 = Integer.parseInt(formatting); //Possible exception may occur here, which is what will be "caught" by the following catch block
                again = false;

            } 
            catch (Exception e) 
            {
                System.out.println("INPUT ERROR: Please enter an integer number!");
                System.out.println(e.getMessage());
            }
        }

    /*** Outputting numbers to the file that are within the range */

        //Handling Exceptions that may occur when writing to the file
        try{ 
            // Open the file.
            PrintWriter outputFile = new PrintWriter(fileName);

            // Writing data to the file
            for (int i = 0; i < numTimes; i++)
            {
            // Outputting the random numbers to the file
            outputFile.println(generateRandomNumber(rangeValue1, rangeValue2));
            }

            // Close the file.
            outputFile.close();
            System.out.println("Data written to the file.");
        }
        catch (IOException e)
        {
        System.out.printf("ERROR writing to file %s!",fileName);
        System.out.printf("ERROR Message: %s!\n",e.getMessage());
        } 
        

        //Closing scanner to prevent resource leak
        userInput.close();

    }


     /** Method generateRandomNumber() is called upon to generate number between two values
     * @param min the left bounding value of the range
     * @param max the right bounding value of the range
     */   
    public static int generateRandomNumber(int min, int max)
    {
        if (min > max) 
        {
            //Switching the values if the min is bigger than the max
            int temp = min;
            min = max;
            max = temp;
        }

        return (int)(Math.random() * ((max - min) + 1)) + min;
  
    }
}
