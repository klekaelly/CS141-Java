public class Point
{

    //Variable Declarations, x and y represent (x, y)
    private double x = 0;
    private double y = 0;

    /** 
     * Constructor Point() overrides the default Java contructor to set the values of (x,y) to 1
     */
    Point()
    {
        x = 1;
        y = 1;
    }

    /** 
     * Constructor to set the value of X and Y to custom doubles
     * @param a The provided X coordinate
     * @param b The provided X coordinate
     */
    Point(double a, double b)
    {
        x = a;
        y = b;
    }

    /** 
     * An accessor method that returns the value of the X coordinate
     * @return The value of the X coordinate
     */
    public double getX() {
        return x;
    }

    /** 
     * An accessor method that returns the value of the Y coordinate
     * @return The value of the Y coordinate
     */
    public double getY() {
        return y;
    }

    /** 
     * An modifier that sets the X coordinate
     * @param a The desired new value of x
     */
    public void setX(double a)
    {
        x = a;
    }

    /** 
     * An modifier that sets the Y coordinate
     * @param a The desired new value of Y
     */
    public void setY(double a)
    {
        y = a;
    }


    /** 
     * An modifier that adds a desired amount of movement to each X , Y coordinate
     * @param a The desired movement for X
     * @param b The desired movement of Y
     */
    public void move(double a, double b)
    {
        x += a;
        y += b;
    }


    /** 
     * An modifier that rotates the coordinates around the origin 90 degrees per method call
     * 
     */
    public void rotate()
    {
        double z;

        z = x;
        x = y;
        y = z * -1;
    }
}   