
import java.io.*;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileReader;

/**
 *
 * @author Alexandra Vaschillo
 */
 
 /**********************************
 IMPORTANT!! IMPORTANT!! IMPORTANT!! 
 
 This code does not compile as it lacks the definitions of the two methods you need to write.
 Before you start workign on it, make sure to write method stubs (placeholders) first. 
 To get an idea of how to do it, check the files I was giving to you in Asg. 2 and 3 - those had the method stubs you were adding code to.

Methods that need stubs are:

numericPattern()
fileAnalysis()

***********************************/

public class Asg04_Part01 {


    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
       
        testNumericPattern();
        testFileAnalysis();
    }

    /** Method numericPattern takes two parameters, size and direction, and returns a string with a pattern of numbers.
     * @param size is the repeatable size of the pattern
     * @param direction defines the direction of the pattern (reversed or not)
     */
    public static String numericPattern(int size, boolean direction)
    {

        //throw illegal argument for invalid size parameter
        if(size <= 0)
        {
            throw new IllegalArgumentException();
        }
       

        //Creation of a new string that can be manipulated before returning
        String returnString = "";
        

        //Creates an incrementing string of values (-1 so there is only a single digit in the apex of the turnaround)
        if (direction == true) 
        {

            //Generates the necessary number of incrementing values in the string (1,2,3,4,5....)
            for (int i = 1; i <= size - 1; i++) 
            {
                returnString = returnString + i;
            }

            //Returns the incrementing string with the value of the size in the middle, followed by a call to a method which reverses the string
            returnString = returnString + "" + size + "" + reverseString(returnString);

            
        }

        //Creates a descending string of values
        if (direction == false) 
        {
            //Resets the value of returnString in case for good measure
            returnString = "";

            //Creates a descending string of values that stops at 2
            for (int i = size; i >= 2; i--) 
            {
                returnString = returnString + i;
            }
            
            //Prints the descending value of returnString, prints a 1 in the middle, followed by a call to reverse the string so that it increments
            returnString = returnString + "" + 1 + reverseString(returnString);
           
        }

        return returnString;
        
    }
   
    /** Method reverseString returns the provided string in reverse order 
     * @param numbers is a string that will be reversed
     */
    public static String reverseString(String numbers)
    {
        char[] array = new char[numbers.length()];
        int numbersIndex = 0;
        for(int i = numbers.length() - 1; i >= 0; i--)
        {
            array [numbersIndex] = numbers.charAt(i);
            numbersIndex++;
        }
        String reverse = "";
        for (int i = 0; i < numbers.length(); i++)
        {
            reverse = reverse + array[i];
        }
        return reverse;
    }

    /**
     * Method fileAnalysis analyzies the first file provided and writes the analysis
     * result to the second file
     * 
     * @param fileOne is the file that will be analyzed
     * @param fileTwo is the file that will be written to
     * @throws IOException
     */
    public static void fileAnalysis(String fileOne, String fileTwo) throws IOException
    {
        //Variable declarations
        int numberofInts = 0; //Total
        int runningTotal = 0; //Sum of all integers in the file
        int max = 0; //Holds max value
        int min = 0; //Holds min value
       

        //Create Scanner and check the file input is valid
        FileReader reader = new FileReader(fileOne); 
        Scanner read = new Scanner(reader);      

    
        //While there is a next line available, perform these operations
        while(read.hasNextLine())
        {
            String line = read.nextLine(); //Line represents the current line of the file 
            
            if (runningTotal == 0)
            {
               
                min = Integer.parseInt(line); //Sets the max value to the first value on the .txt
                max = Integer.parseInt(line); //Sets the min value to the first value on the .txt
            }
            //If the current integer is bigger than the max, set the integer to the max
            if(max < Integer.parseInt(line))
            {
                max = Integer.parseInt(line);
            }
            //If the current integer is smaller than the min, set the integer to the min
            if(min > Integer.parseInt(line))
            {
                min = Integer.parseInt(line);
            }

            //Increment every loop to track how many integers there are
            numberofInts++;

            //Add each line/integer to the running total for the complete value of all digits
            runningTotal = runningTotal + Integer.parseInt(line);
        }

        read.close();
        reader.close();

        /* Writing the Output */
        FileWriter outputFile = new FileWriter(fileTwo, false);
        
        //If the number of integers is 0, say the file is empty
        if (numberofInts == 0)
        {
            outputFile.write("Numeric data file \"" + fileOne + "\" is empty");
            outputFile.close();
        }

        //If the number of integers is 1, say the file only has 1 integar and print the runningTotal
        if (numberofInts == 1)
        {
            outputFile.write("Numeric data file \"" + fileOne + "\" has only one number: " + runningTotal);
            outputFile.close();
        } 

        if(numberofInts > 1)
        {
        //For anything else, print the output to the outputFile
        outputFile.write("Numeric Data File \"" + fileOne + "\" Analysis\r\n");
        outputFile.write("Number of integers: " + numberofInts + "\r\n");
        outputFile.write("The sum of all integers in file: " + runningTotal + "\r\n");
        outputFile.write("The largest integer in the set: " + max + "\r\n");
        outputFile.write("The smallest integer in the set: " + min + "\r\n");
        outputFile.close();
        }
        
            
       
        

    }
    
   /**
    * Method runs all test cases for numericPattern() method 
    */ 
   public static void testNumericPattern()
   {
       System.out.println("\n--------- numericPattern() Tests ---------");
         
       //--- Test 1 ---//
        if(numericPattern(1, true).equals("1")&&numericPattern(1, false).equals("1")) System.out.println("Test 1 for numericPattern() PASSED");
        else System.out.println("Test 1 for numericPattern() Failed");
       
        //--- Test 2 ---//
        if(numericPattern(5, false).equals("543212345")&& numericPattern(6, true).equals("12345654321")) System.out.println("Test 2 for numericPattern() PASSED");
        else System.out.println("Test 2 for numericPattern() Failed");
        
        //--- Test 3 ---//
        try
        {
            String ignoreMe = numericPattern(0, false);
            System.out.println("Test 3 for numericPattern() Failed");
        }
        catch (IllegalArgumentException e)
        {
            System.out.println("Test 3 for numericPattern() PASSED");
        }

        //--- Test 4 ---//
        try
        {
            String ignoreMe = numericPattern(-55, false);
            System.out.println("Test 4 for numericPattern() Failed");
        }
        catch (IllegalArgumentException e)
        {
            System.out.println("Test 4 for numericPattern() PASSED");
        }       
       
   }
  
   /**
    * Method runs all test cases for fileAnalysis() method 
    * The method generates a number of test case files. 
    * Please see those files to make sure your file output format matches the output format in test files
    */
   public static void testFileAnalysis()
   {
      // Data needed for the test cases is built here
      System.out.println("\n--------- fileAnalysis() Tests ---------");
      Integer[] testIn1 = {};
      String[] testOut1 = {"Numeric data file \"testCaseIn1.txt\" is empty"};
      Integer[] testIn2 = {0};
      String[] testOut2 = {"Numeric data file \"testCaseIn2.txt\" has only one number: 0"};
      Integer[] testIn3 = {0, 0};
      String[] testOut3 = {"Numeric Data File \"testCaseIn3.txt\" Analysis", "Number of integers: 2","The sum of all integers in file: 0", "The largest integer in the set: 0", "The smallest integer in the set: 0"};      
      Integer[] testIn4 = {33, 1, 0, 2}; 
      String[] testOut4 = {"Numeric Data File \"testCaseIn4.txt\" Analysis", "Number of integers: 4","The sum of all integers in file: 36", "The largest integer in the set: 33", "The smallest integer in the set: 0"};      
      Integer[] testIn5 = {Integer.MAX_VALUE, Integer.MAX_VALUE};
      String[] testOut5 = {"Numeric Data File \"testCaseIn5.txt\" Analysis", "Number of integers: 2","The sum of all integers in file: -2", "The largest integer in the set: 2147483647", "The smallest integer in the set: 2147483647"};      
      Integer[] testIn6 = {Integer.MIN_VALUE, Integer.MAX_VALUE};
      String[] testOut6 = {"Numeric Data File \"testCaseIn6.txt\" Analysis", "Number of integers: 2","The sum of all integers in file: -1", "The largest integer in the set: 2147483647", "The smallest integer in the set: -2147483648"};      
   
     
      // building test case files 
      try
      {
        buildTestFile("testCaseIn1.txt", testIn1); 
        buildTestFile("testCaseOut1.txt", testOut1);
        buildTestFile("testCaseIn2.txt", testIn2);
        buildTestFile("testCaseOut2.txt", testOut2);
        buildTestFile("testCaseIn3.txt", testIn3);
        buildTestFile("testCaseOut3.txt", testOut3);
        buildTestFile("testCaseIn4.txt", testIn4);
        buildTestFile("testCaseOut4.txt", testOut4);
        buildTestFile("testCaseIn5.txt", testIn5);
        buildTestFile("testCaseOut5.txt", testOut5);
        buildTestFile("testCaseIn6.txt", testIn6);
        buildTestFile("testCaseOut6.txt", testOut6);
      }
      catch(IOException e)
      {
          System.out.println("Trouble with file IO when building test case files");
      }

      try
      {
        //--- Test 1 ---//        
       
        fileAnalysis("testCaseIn1.txt", "test01.txt");
        // comparign resulting files
        if(areEqualFiles("testCaseOut1.txt", "test01.txt"))System.out.println("Test 1 for fileAnaylysis() PASSED");
        else System.out.println("Test 1 for fileAnaylysis() Failed");
 
        //--- Test 2 ---//        
        fileAnalysis("testCaseIn2.txt", "test02.txt");   
             
        if(areEqualFiles("testCaseOut2.txt", "test02.txt"))System.out.println("Test 2 for fileAnaylysis() PASSED");
        else System.out.println("Test 2 for fileAnaylysis() Failed");  
        
        //--- Test 3 ---//        
        fileAnalysis("testCaseIn3.txt", "test03.txt");  
        
        if(areEqualFiles("testCaseOut3.txt", "test03.txt"))System.out.println("Test 3 for fileAnaylysis() PASSED");
        else System.out.println("Test 3 for fileAnaylysis() Failed"); 
        
        //--- Test 4 ---//        
        fileAnalysis("testCaseIn4.txt", "test04.txt"); 
        
        if(areEqualFiles("testCaseOut4.txt", "test04.txt"))System.out.println("Test 4 for fileAnaylysis() PASSED");
        else System.out.println("Test 4 for fileAnaylysis() Failed"); 
        
        //--- Test 5 ---//        
        fileAnalysis("testCaseIn5.txt", "test05.txt"); 
        
        if(areEqualFiles("testCaseOut5.txt", "test05.txt"))System.out.println("Test 5 for fileAnaylysis() PASSED");
        else System.out.println("Test 5 for fileAnaylysis() Failed"); 
        
        //--- Test 6 ---//       
        fileAnalysis("testCaseIn6.txt", "test06.txt"); 
        
        if(areEqualFiles("testCaseOut6.txt", "test06.txt"))System.out.println("Test 6 for fileAnaylysis() PASSED");
        else System.out.println("Test 6 for fileAnaylysis() Failed"); 
 
        
        //--- Test 7 ---//
        // Test on exception(s) that your method is supposed to throw
        fileAnalysis("doesNotExist.txt", "test07.txt"); 
        System.out.println("Test 7 for fileAnaylysis() Failed"); 
      }
      catch(FileNotFoundException e)
      {
          System.out.println("Test 7 for fileAnaylysis() PASSED");
      }
      catch(IOException e)
      {
          System.out.println("Trouble with file IO when running tests");
      }
   
      
   }
   /**
    * Builds a file with a given name with a content defined by an array of objects that are printed to the file as strings, one string per line  
    * @param fileName name of file to write to
    * @param testCase array of objects to print into file in string format
    * @throws IOException throws exception when file fails to open for writing or writing fails
    */
   public static void buildTestFile(String fileName, Object[] testCase) throws IOException
   {
        FileWriter file = new FileWriter(fileName); 
        PrintWriter outputFile = new PrintWriter(file);
        
        for (Object a: testCase)
        {
            outputFile.println(a);
        }
        outputFile.close();
   }
   /**
    * Compares content of two files and returns true if content is identical, false if not
    * @param fileName1 name of first file to be compared
    * @param fileName2 name of second file to be compared
    * @return true if the files are identical, false if not
    * @throws IOException thrown when files fail to open for reading / writing
    */
   public static boolean areEqualFiles(String fileName1, String fileName2) throws IOException
   {
        FileReader file1 = new FileReader(fileName1); 
        FileReader file2 = new FileReader(fileName2); 
        Scanner input1 = new Scanner(file1);
        Scanner input2 = new Scanner(file2);
        while(input1.hasNext()&&input2.hasNext())
        {
            String s1 = input1.nextLine().trim();
            String s2 = input2.nextLine().trim();
            if(!s1.equals(s2)) 
            {
                input1.close();
                input2.close();
                return false;
            }
        }
        boolean res;
        if(!input1.hasNext()&&!input2.hasNext()) res = true;
        else res = false;
        input1.close();
        input2.close();
        return res;
        
   }
}

