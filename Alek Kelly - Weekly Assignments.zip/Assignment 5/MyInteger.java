public class MyInteger {


  //Data fields
  private int integer;
  private boolean flag = false;

  /**
   * Constructor assigns the value of X to a local variable integer
   * @param x
   */
  MyInteger(int x) 
  {
      integer = x;
  }

  /**
   * Method returns the value of integer
   * @return the value of integer
   */
  public int toInteger()
  {
      return integer;
  }

  /**
   * Instance method tells if integer is even
   * @return True if integer is even
   */
  public boolean isEven() 
  {
      return integer % 2 == 0;
  }

  /**
   * Instance method tells if integer is odd
   * @return True if integer is odd
   */
  public boolean isOdd() 
  {
      return integer % 2 != 0;
  }

  /**
   * Instance method tests the number to see if it is prime
   * @return True if value is prime
   */
  public boolean isPrime() 
  {
      
      for (int i = 2; i <= integer / 2; ++i) 
      {
          if (integer % i == 0) 
          {
              flag = true;
              break;
          }
      }

      if (!flag) 
      {
          return true;
      } else {
          return false;
      }
  }
  /**
   * Instance method returns true if the value in this object is equal to the specified value
   * @param x A supplied integer value
   * @return True if this instance's value is the same as the provided value
   */
  public boolean equals(int x)
  {
      return integer == x;
  }

  /**
   * Instance method returns true if the value in this object is equal to the specified value
   * @param MyInteger A supplied value in another instance of the class
   * @return True if the current instance's value is the same as the other class's value
   */
  public boolean equals(MyInteger x)
  {
      return equals(x.toInteger());
  }

  

  /**
   * Static method tells if provided number is even
   * @param x A supplied value to be checked if even
   * @return True if provided number is even
   */
  public static boolean isEven(int x) 
  {
      return x % 2 == 0;
  }

  /**
   * Static method tells if the provided number is odd
   * @param x A supplied value to be checked if odd
   * @return True if the provided number is odd
   */
  public static boolean isOdd(int x) 
  {
      
      return x % 2 != 0;
      
  }

  /**
   * Static method tests the provided number to see if it is prime
   * @param x A supplied value to be checked if prime
   * @return True if value is prime
   */
  public static boolean isPrime(int x) 
  {
      boolean flag = false;

      for (int i = 2; i <= x / 2; ++i) 
      {
          if (x % i == 0) 
          {
              flag = true;
              break;
          }
      }

      if (!flag) 
      {
          return true;
      } else {
          return false;
      }
  }
  
  /**
   * Static method that parses the string and returns an integer made of it's
   * values
   * 
   * @param s A supplied String to be parsed and
   * @return an int with the int values of the string
   */
  public static int parseInt(String s) throws IllegalArgumentException 
  {
      if (s == null) {
          throw new NumberFormatException("null");
      }

      if (10 < Character.MIN_RADIX) 
      {
          throw new NumberFormatException();
      }

      if (10 > Character.MAX_RADIX) 
      {
          throw new NumberFormatException();
      }

      boolean negative = false;
      int i = 0;
      int lenth = s.length();
      int limit = -Integer.MAX_VALUE;

      if (lenth > 0) 
      {
          char firstChar = s.charAt(0);

          if (firstChar < '0') 
          {
              if (firstChar == '-') 
              {
                  negative = true;
                  limit = Integer.MIN_VALUE;
              } 

              if (lenth == 1) 
              {
                  throw new IllegalArgumentException();
              }

              i++;
          }

          int multmin = limit / 10;
          int result = 0;

          while (i < lenth) 
          {
              int digit = Character.digit(s.charAt(i++), 10);
              if (digit < 0 || result < multmin) 
              {
                  throw new IllegalArgumentException();
              }

              result *= 10;

              if (result < limit + digit) 
              {
                  throw new IllegalArgumentException();
              }
              result -= digit;
          }

          return negative ? result : -result;
      } 

      else 

      {
          throw new IllegalArgumentException();
      }
  }

}
