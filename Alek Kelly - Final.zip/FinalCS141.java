package Final;

/* B */
import java.io.*;
import java.util.*;
/**
 * 
 * @author Alexandra Vaschillo
 *
 */
public class FinalCS141 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        int total = 0;
        int expectedTotal = 100;
        PrintStream out = System.out;
        int tmp = 0;
     
        tmp = testsProblem01(out);
        out.printf("\nYou earned %d out of %d points for problem01()\n", tmp, 25);
        total+=tmp;
        
        tmp = testsProblem02(out);
        out.printf("\nYou earned %d out of %d points for problem02()\n", tmp, 25);
        total+=tmp;
       
        tmp = testsProblem03(out);
        out.printf("\nYou earned %d out of %d points for problem03()\n", tmp, 25);
        total+=tmp;  
        
                
        tmp = testsClassB_getFirstMethod(out);
        out.printf("\nYou earned %d out of %d points for ClassB getFirst() method\n", tmp, 10);
        total+=tmp; 
        
        tmp = testsClassBCopyConstructor(out);
        out.printf("\nYou earned %d out of %d points for ClassB copy constructor\n", tmp, 15);
        total+=tmp; 
          
        out.printf("\nYou earned %d out of %d points for Final Exam\n", total, expectedTotal);             
    }
	
    
    /**
     * Method runs all test cases for problem01() method 
     * The method generates a number of test case files. 
     * Please see those files to make sure your file output format matches the output format in test files
     */
    public static int testsProblem01(PrintStream outputStream)
    {
         int expectedCount = 4;
         int count = 0;
         int pointValue = 25;
       
       outputStream.println("\n--------- problem01() Tests ---------");
    
       // Data needed for the test cases is built here
       String[] testOut1 = {"*"};     
       String[] testOut2 = {"-", "**"};   
       String[] testOut3 = {"*", "--", "***"};
       String[] testOut4 = {"-", "**", "---", "****", "-----", "******", "-------", "********"};         
       String[] testOut5 = {"*", "--", "***", "----", "*****", "------", "*******", "--------", "*********"};        
           
       // building test case files 
       try
       {
         buildTestFile("PR01_testCaseOut1.txt", testOut1);
         buildTestFile("PR01_testCaseOut2.txt", testOut2);
         buildTestFile("PR01_testCaseOut3.txt", testOut3);
         buildTestFile("PR01_testCaseOut4.txt", testOut4);
         buildTestFile("PR01_testCaseOut5.txt", testOut5);
       }
       catch(IOException e)
       {
           System.out.println("Trouble with file IO when building test case files");
       }

       try
       {   
              
         AllStaticMethods.problem01("PR01_test1.txt", 1);
         AllStaticMethods.problem01("PR01_test2.txt", 2);
         AllStaticMethods.problem01("PR01_test3.txt", 3);
         AllStaticMethods.problem01("PR01_test4.txt", 8);
         AllStaticMethods.problem01("PR01_test5.txt", 9);
       
         //--- Test 1 ---//
         // comparing resulting files
         if(areEqualFiles("PR01_testCaseOut1.txt", "PR01_test1.txt")
        		 && areEqualFiles("PR01_testCaseOut2.txt", "PR01_test2.txt") 
        		 && areEqualFiles("PR01_testCaseOut3.txt", "PR01_test3.txt") 
        		 && areEqualFiles("PR01_testCaseOut4.txt", "PR01_test4.txt") 
        		 && areEqualFiles("PR01_testCaseOut5.txt", "PR01_test5.txt"))
         {
             outputStream.printf("%-80s%-10s\r\n", "problem01() TEST 01 - regular functionality",  "PASSED");
             count++;
         }
         else outputStream.printf("%-80s%-10s\r\n", "problem01() TEST 01 - basic functionality",  "FAILED");
  
         //--- Test 2 ---//        
         try
         {
            AllStaticMethods.problem01("someFile.txt", 0); 
            outputStream.printf("%-80s%-10s\r\n", "problem01() TEST 02 - IllegalArgumentException - zero",  "FAILED");
            
         }
         catch(IllegalArgumentException e)
         {
             outputStream.printf("%-80s%-10s\r\n", "problem01() TEST 02 - IllegalArgumentException - zero",  "PASSED");
             count++;
         }
         
         //--- Test 3 ---//        
         try
         {
            AllStaticMethods.problem01("someFile.txt", -1); 
            outputStream.printf("%-80s%-10s\r\n", "problem01() TEST 03 - IllegalArgumentException - negative value",  "FAILED");
            
         }
         catch(IllegalArgumentException e)
         {
             outputStream.printf("%-80s%-10s\r\n", "problem01() TEST 03 - IllegalArgumentException - negative value",  "PASSED");
             count++;
         }
         
         //--- Test 4 ---//
        
         try
         {
            AllStaticMethods.problem01("some/File.txt", 1); 
            outputStream.printf("%-80s%-10s\r\n", "problem01() TEST 03 - IOException",  "FAILED");
            
         }
         catch(IOException e)
         {
             outputStream.printf("%-80s%-10s\r\n", "problem01() TEST 03 - IOException",  "PASSED");
             count++;
         }
       }
      
       catch(IOException e)
       {
           System.out.println("IOException occured while running tests; MESSAGE: "+e.getMessage());
       }
       if (count==expectedCount) return pointValue;
       else return 0;  
       
    }
    
    /**
     * Method runs all test cases for problem02() method 
     * The Method generates a number of test case files. 
     * Please see those files to make sure your file output format matches the output format in test files
     */
    public static int testsProblem02(PrintStream outputStream)
    {
        int expectedCount = 3;
        int count = 0;
        int pointValue = 25;
      
       outputStream.println("\n--------- problem02() Tests ---------");
    // Data needed for the test cases is built here
       Integer[] testIn1 = {3, 33, 1, 22, 7, 8};
       
       Integer[] testOut1 = {3, 1, 7, 33, 22, 8};     
       Integer[] testOut2 = {3, 1, 33, 22, 7, 8};       
       Integer[] testOut3 = {3, 1, 22, 7, 8, 33};           
       Integer[] testOut4 = {3, 33, 1, 22, 7, 8};      
       
       Integer[] testIn5 = {};
       Integer[] testOut5 = {};   

       Integer[] testIn6 = {9};
       Integer[] testOut6 = {9};        
    
       try{
        
         // building test case files 
         buildTestFile("PR02_test01.txt", testIn1); 
         buildTestFile("PR02_test02.txt", testIn1);
         buildTestFile("PR02_test03.txt", testIn1);
         buildTestFile("PR02_test04.txt", testIn1);
         buildTestFile("PR02_test05.txt", testIn5);
         buildTestFile("PR02_test06.txt", testIn6);
         
         
         buildTestFile("PR02_testCaseOut1.txt", testOut1);             
         buildTestFile("PR02_testCaseOut2.txt", testOut2);                    
         buildTestFile("PR02_testCaseOut3.txt", testOut3);        
         buildTestFile("PR02_testCaseOut4.txt", testOut4);          
         buildTestFile("PR02_testCaseOut5.txt", testOut5);
         buildTestFile("PR02_testCaseOut6.txt", testOut6);
         
         // calling methods
         //files test01.txt, test02.txt, test03.txt, test04.txt are identical and contain values {3, 33, 1, 22, 7, 8}
         AllStaticMethods.problem02("PR02_test01.txt", 7);
         AllStaticMethods.problem02("PR02_test02.txt", 4);
         AllStaticMethods.problem02("PR02_test03.txt", 22);
         AllStaticMethods.problem02("PR02_test04.txt", 0);
         AllStaticMethods.problem02("PR02_test05.txt", 6);
         AllStaticMethods.problem02("PR02_test06.txt", 100);
         
         //--- Test 1 ---//
      // comparing resulting files with test cases
         if(areEqualFiles("PR02_testCaseOut5.txt", "PR02_test05.txt") 
             && areEqualFiles("PR02_testCaseOut6.txt", "PR02_test06.txt"))      		
         {
             outputStream.printf("%-80s%-10s\r\n", "problem02() TEST 01 - empty file and file with 1 number",  "PASSED");
             count++;
         }
         else outputStream.printf("%-80s%-10s\r\n", "problem02() TEST 01 - empty file and file with 1 number",  "FAILED");
         
  
         //--- Test 2 ---//
         if(areEqualFiles("PR02_testCaseOut1.txt", "PR02_test01.txt") 
        		 && areEqualFiles("PR02_testCaseOut2.txt", "PR02_test02.txt")
        		 && areEqualFiles("PR02_testCaseOut3.txt", "PR02_test03.txt")
        		 && areEqualFiles("PR02_testCaseOut4.txt", "PR02_test04.txt"))      		
         {
             outputStream.printf("%-80s%-10s\r\n", "problem02() TEST 02 - regular functionality",  "PASSED");
             count++;
         }
         else outputStream.printf("%-80s%-10s\r\n", "problem02() TEST 02 - regular functionality",  "FAILED");
         
         
         //--- Test 3 ---//
         
         try
         {
            AllStaticMethods.problem02("someFile.txt", 3); 
            outputStream.printf("%-80s%-10s\r\n", "problem02() TEST 03 - IOException",  "FAILED");
            
         }
         catch(IOException e)
         {
             outputStream.printf("%-80s%-10s\r\n", "problem02() TEST 03 - IOException",  "PASSED");
             count++;
         }
         
       }
       catch(IOException e)
       {
           System.out.println("IOException occured while running tests; MESSAGE: "+e.getMessage());
       }
    
       if (count==expectedCount) return pointValue;
       else return 0;  
    }
    
    /**
     * Runs all tests for problem03() method
     * @param outputStream - output stream, used to print into the screen
     * @return number of points the problem is worth if all the tests ran successfully. If any of the tests failed the method returns a 0.
     */
    public static int testsProblem03(PrintStream outputStream)
    {
        int expectedCount = 2;
        int count = 0;
        int pointValue = 25;

  
        outputStream.println("\r\n----Tests for problem03()----\r\n");
        
        // will be looking for object [1, 1.0] - must find 3 occurrences
        
        ClassA[] test01 = new ClassA[5];
        test01[0] = new ClassA(1, 1.0);
        test01[1] = new ClassA(2, 1.0);
        test01[2] = new ClassA(2, 3.0);
        test01[3] = new ClassA(1, 1.0);
        test01[4] = new ClassA(1, 1.0); 
   
        // empty
        ClassA[] test04 = new ClassA[0];
        
        // one element 
        ClassA[] test05 = {new ClassA(1, 1.0)};
        
        ClassA obj1 = new ClassA(1, 1.0);
        ClassA obj2 = new ClassA(3, 13.0);
 
        //--- Test 1 ---//
        
        if(AllStaticMethods.problem03(test01, obj1) == 3 
        		&& AllStaticMethods.problem03(test01, obj2) == 0)   
        {
            outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 01 - basic functionality",  "PASSED");
            count++;
        }
        else outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 01 - basic functionality",  "FAILED");
 
        //--- Test 2 ---//
        
        if(AllStaticMethods.problem03(test04, obj1) == 0 
        		&& AllStaticMethods.problem03(test05, obj1) == 1
        		&& AllStaticMethods.problem03(test05, obj2) == 0)  
        {
            outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 02 - edge cases",  "PASSED");
            count++;
        }
        else outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 02 - edge cases",  "FAILED");
        
        if(count == 2) return 25;
        else return 0;
    }
 
	/**
	 * Runs all tests for ClassB equals() method
	 * @param outputStream - output stream, used to print into the screen
	 * @return number of points the problem is worth if all the tests ran successfully. If any of the tests failed the method returns a 0.
	 */
	public static int testsClassB_getFirstMethod(PrintStream outputStream)
	{
	    int expectedCount = 2;
	    int count = 0;
	    int pointValue = 10;
	
	    outputStream.println("\r\n----Tests for ClassB getFirst() method ----\r\n");
	    ClassB t1 = new ClassB();
	    for(int i = 1; i<11; i++)
	    {
	    	Integer tmp = i;
	    	t1.push(tmp.toString());
	    }
	    
	    ClassB empty = new ClassB(); // empty 

	  //--- Test 1 ---//
	    if(t1.getFirst().toString().equals("[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]") 
	    		&& empty.getFirst().toString().equals("[]"))       
	    {
	        outputStream.printf("%-80s%-10s\r\n", "ClassB getFirst() method TEST 01 - regular functionality",  "PASSED");
	        count++;
	    }
	    else outputStream.printf("%-80s%-10s\r\n", "ClassB getFirst() method TEST 01 - regular functionality",  "FAILED");
	
	  //--- Test 2 ---//
	    
	    ArrayList<String> tmp = t1.getFirst();
	    tmp.add("hello");
	
	    if(t1.getFirst().toString().equals("[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]") )       
	    {
	        outputStream.printf("%-80s%-10s\r\n", "ClassB getFirst() method TEST 02 - deep copy test",  "PASSED");
	        count++;
	    }
	    else outputStream.printf("%-80s%-10s\r\n", "ClassB getFirst() method TEST 02 - deep copy test",  "FAILED");
	
	    
	    if (count==expectedCount) return pointValue;
	     else return 0;
	}

	/**
	 * Runs all tests for ClassB Copy Constructor 
	 * @param outputStream - output stream, used to print into the screen
	 * @return number of points the problem is worth if all the tests ran successfully. If any of the tests failed the method returns a 0.
	 */
	public static int testsClassBCopyConstructor(PrintStream outputStream)
	{
	    int expectedCount = 2;
	    int count = 0;
	    int pointValue = 15;
	
	    outputStream.println("\r\n----Tests for ClassB Copy Constructor----\r\n");
	    ClassB obj = new ClassB();
	    
	    for(int i = 0; i<10; i++)
	    {
	    	Integer tmp = i+3;
	    	obj.push(tmp.toString());
	    }
	    
	    ClassB objCopy = new ClassB(obj);

	  //--- Test 1 ---//
	    if(objCopy.toString().equals("{first=[3, 4, 5, 6, 7, 8, 9, 10, 11, 12]; second=10}"))       
	    {
	        outputStream.printf("%-80s%-10s\r\n", "ClassB copy constr. TEST 01 - basic functionality",  "PASSED");
	        count++;
	    }
	    else outputStream.printf("%-80s%-10s\r\n", "ClassB copy constr. TEST 01 - basic functionality",  "FAILED");
	
	  //--- Test 2 ---//
	    
	    obj.push("hello");
	
	    if(objCopy.toString().equals("{first=[3, 4, 5, 6, 7, 8, 9, 10, 11, 12]; second=10}"))       
	    {
	        outputStream.printf("%-80s%-10s\r\n", "ClassB copy constr. TEST 02 - deep copy of fields",  "PASSED");
	        count++;
	    }
	    else outputStream.printf("%-80s%-10s\r\n", "ClassB copy constr. TEST 02 - deep copy of fields",  "FAILED");               
	
	    
	    if (count==expectedCount) return pointValue;
	     else return 0;
	}
	 
    /**
     * Builds a file with a given name with a content defined by an array of objects that are printed to the file as strings, one string per line  
     * @param fileName name of file to write to
     * @param testCase array of objects to print into file in string format
     * @throws IOException throws exception when file fails to open for writing or writing fails
     */
    public static void buildTestFile(String fileName, Object[] testCase) throws IOException
    {
         FileWriter file = new FileWriter(fileName); 
         PrintWriter outputFile = new PrintWriter(file);
         
         for (Object a: testCase)
         {
             outputFile.println(a);
         }
         outputFile.close();
    }
    /**
     * Compares content of two files and returns true if content is identical, false if not
     * @param fileName1 name of first file to be compared
     * @param fileName2 name of second file to be compared
     * @return true if the files are identical, false if not
     * @throws IOException thrown when files fail to open for reading / writing
     */
    public static boolean areEqualFiles(String fileName1, String fileName2) throws IOException
    {
         FileReader file1 = new FileReader(fileName1); 
         FileReader file2 = new FileReader(fileName2); 
         Scanner input1 = new Scanner(file1);
         Scanner input2 = new Scanner(file2);
         while(input1.hasNext()&&input2.hasNext())
         {
             String s1 = input1.nextLine().trim();
             String s2 = input2.nextLine().trim();
             if(!s1.equals(s2)) 
             {
                 input1.close();
                 input2.close();
                 return false;
             }
         }
         boolean res;
         if(!input1.hasNext()&&!input2.hasNext()) res = true;
         else res = false;
         input1.close();
         input2.close();
         return res;      
    }
    
    
}
