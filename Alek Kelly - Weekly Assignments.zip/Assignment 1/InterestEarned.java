
//Import statements
import static java.lang.System.in;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Alek Kelly
 *
 */

//Class declaration
class InterestEarned 
{
    //Main Method Declaration
    public static void main(String[] args) 
    {




        /***** The following section  is where all the variables are Declared *****/
        int timesCompounded;        //This variable holds the user's input of number of times compounded
        double principalInvestment; //This variable holds the user's input of the principal amount investment
        double interestRate;        //This variable holds the user's input of the interest rate
        double compoundedAmount;    //This variable is where the calculated compounded amount will be stored
        double interestAmount;      //This variable stores the amount of interest earned




        /***** The following section takes user input *****/

        //Creates a scanner object to read user input
         Scanner userInput = new Scanner(in);

        //Prompts user for Interest Rate and assigns it to predetermined variable
        System.out.println("What is the interest rate?");
        interestRate = convertPercDec(userInput.nextDouble());

        //Prompts user for number of times compounded and assigns it to predetermined variable
        System.out.println("How many times compounded?");
        timesCompounded = userInput.nextInt();

        //User cannot enter 0, because we don't want to divide by 0 in the method calculateInterest
        if (timesCompounded == 0)
        {
            System.out.println("Invalid Number. Please try any integer larger than 0.");
        }

        //Prompts user for Principal Amount and Assigns it to the predetermined variable
        System.out.println("What is your principal amount?");
        principalInvestment = userInput.nextDouble();

        //
        interestAmount = calculateInterest (principalInvestment, timesCompounded, interestRate);
        
        System.out.println(formatCurrency(interestAmount));
        compoundedAmount = interestAmount + principalInvestment;

        //Closes scanner to prevent resource leak
        userInput.close();


        /***** The following section is responsible for echoeing the inputs of the user and printing the results *****/

        //Prints out the Interest Rate:
        System.out.println("Interest Rate:          " + convertDecPerc(interestRate) + "%");

        //Prints out the times compounded
        System.out.println("Times Compounded:       " + timesCompounded);
       
        //Prints out the Principal Amount Invested
        System.out.println("Principal:              $" + principalInvestment);

        //Prints out the amount earned on interest
        System.out.println("Interest:               $" + formatCurrency(interestAmount));

        //Prints out the amount in savings
        System.out.println("Amount in Savings:      $" + formatCurrency(compoundedAmount));
    }


    //Calculates the Amount of Interest WITHOUT the principal amount
    public static double calculateInterest(double x , int y, double z)
    {
        return (x * (Math.pow( (1 + ( z / y ) ) , y )) - x);
    }

    //Converts values from decimals to percentages by multiplying the value by 100
    public static double convertDecPerc(double x)
    {
        return x * 100;
    }

    //Converts values from percentages to decimals by dividing the value by 100
    public static double convertPercDec(double x)
    {
        return x / 100;
    }

    // Creates a decimal format string to define the total amount output in terms of real currency. This method always rounds up (You can't have half a cent..)
    public static String formatCurrency(double x) 
    {
        DecimalFormat df = new DecimalFormat(".##");
        df.setRoundingMode(RoundingMode.UP);

        return df.format(x);
    }
}
