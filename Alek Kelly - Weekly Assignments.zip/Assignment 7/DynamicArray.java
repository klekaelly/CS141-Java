public class DynamicArray 
{

    private int[] array;
    private int size;

    //No Argument Constructor
    DynamicArray() {
        this(3);
        size = 0;
    }

    // Copy constructor with Parameter
    DynamicArray(int arraySize) {
        if (arraySize < 0)
            throw new IllegalArgumentException("Array declaration cannot be less than 0");

        array = new int[arraySize];
        size = 0;
    }

    // Copy constructor that returns a copy of the original object
    public DynamicArray(DynamicArray source) {
        if (source == null)
            throw new IllegalArgumentException();

        int[] copy = new int[source.getCapacity()];
        this.size = source.size;

        int i;

        for (i = 0; i < source.getCapacity(); i++) {
            copy[i] = source.array[i];
        }
        this.array = copy;
    }

    /**
     * Gets the number of occupied elements in an array
     * 
     * @return The number of occupied elements of an array
     */
    public int getSize() {
        return size;
    }

    /**
     * Gets the capacity of the array
     * 
     * @return the value of the field size
     */
    public int getCapacity() {
        return array.length;
    }

    /**
     * Returns true if the size of the array is 0
     * 
     * @return true if the size of the array is 0
     */
    public boolean isEmpty() {
        if (this.getSize() == 0)
            return true;

        return false;
    }

    /**
     * Provides a copy of the entire partially filled array
     * 
     * @return the copied array
     */
    public int[] getArray() {
        return copyArray();
    }

    /**
     * Adds a new element to the end of the array and increments the size field. If
     * the array is full, it increases the capacity of the array
     * 
     * @param num The new element
     * 
     */
    public void push(int num) {

        if (array.length == getSize()) {
            int[] copy = new int[this.array.length * 2];

            int i;

            for (i = 0; i < array.length; i++) {
                copy[i] = this.array[i];
            }

            copy[i] = num;
            size++;
            array = copy;

        } else {

            array[getSize()] = num;
            size++;

        }

    }

    /**
     * Removes the last element of the array and returns it
     * 
     * @throws RuntimeException when the array is empty
     * 
     */
    public int pop() throws RuntimeException {
        if (getSize() == 0)
            throw new RuntimeException("Array is empty");

        int returnvalue = this.array[getSize() - 1];
        size--;

        if (getCapacity() > getSize() * 4) {
            int[] copy = new int[this.array.length / 2];

            for (int i = 0; i < copy.length; i++) {
                copy[i] = this.array[i];
            }

            this.array = copy;
        }

        return returnvalue;
    }

    /**
     * Returns element of the array at the requested index
     * 
     * @param index the index of the requested value
     * @return Value at requested index
     * @throws IndexOutOfBoundsException when index is illegal
     */
    public int get(int index) throws IndexOutOfBoundsException {

        if (index > getSize() || 0 > index)
            throw new IndexOutOfBoundsException("Illegal Index");

        return array[index];
    }

    /**
     * Returns the index of the first occurrence of the given number
     * 
     * @param key the number being checked for
     * @return the index of that number, -1 if not found
     */
    public int indexOf(int key) {
        for (int i : array) {
            if (array[i] == key) {
                return i;
            }
        }

        return -1;
    }

    /**
     * Returns the occupied part of a partially filled array
     *
     * @return a copy of the occupied part of the array
     */
    public int[] toArray() {
        int[] copy = new int[getSize()];

        for (int i = 0; i < getSize(); i++) {
            copy[i] = this.array[i];
        }

        return copy;
    }

    /**
     * Adds a number to a specific index in the sequence, moves everything over,
     * doubles size of array as necessary
     * 
     * @param index The new value being added
     * @param num   The new value being added
     * @throws IndexOutOfBoundsException when the provided index is invalid
     */
    public void add(int index, int num) throws IndexOutOfBoundsException {
        int newLength = getCapacity();

        if (index > getCapacity() || index < 0)

            throw new IndexOutOfBoundsException();

        if (getSize() == getCapacity()) {
            newLength = getSize() * 2;
        }

        int[] copy = new int[newLength];

        for (int j = 0, i = 0; j < getCapacity(); i++, j++) {
            if (i == index) {
                copy[index] = num;
                size++;
                j++;
            }
            copy[j] = array[i];
        }
        array = copy;
    }

    /**
     * Removes a value at specified index and closes gap, shrink overall size if
     * necessary
     * 
     * @param index The subscript of the value that will be removed
     * @return The removed value at the specified index
     * @throws IndexOutOfBoundsException when the specified index is invalid
     */
    public int remove(int index) throws IndexOutOfBoundsException {
        int newLength = getCapacity();
        int removedValue = array[index];

        if (index >= getSize() || index < 0)
            throw new IndexOutOfBoundsException();

        if (getSize() * 4 < newLength) {
            newLength = newLength / 2;
        }

        int[] copy = new int[newLength];

        for (int i = 0, j = 0; i < getSize(); i++, j++) {
            if (i == index) {
                i++;

            }
            copy[j] = array[i];
        }
        size--;
        array = copy;
        return removedValue;
    }

    /**
     * This method returns a copy of the Array
     * 
     * @return A copy of the original array
     */
    public int[] copyArray() {
        int[] copy = new int[this.array.length];

        for (int i = 0; i < this.array.length; i++) {
            copy[i] = this.array[i];
        }

        return copy;
    }

    /**
     * Prints one dimensional arrays to the console
     * 
     * @param notes The array[ ] to be printed
     */
    public void printArray() {
        for (Object x : array) {

            System.out.print(x + "\n");
        }
    }

    /**
     * Finds the smallest number in the array
     * 
     * @throws RuntimeException if array is empty
     * @return The smallest number in the array
     */
    public int findMin() throws RuntimeException {
        if (isEmpty())
            throw new RuntimeException("Array is Empty.");

        int minValue = array[0];

        for (int i = 0; i < getSize(); i++) {
            if (array[i] < minValue) {
                minValue = array[i];
            }
        }

        return minValue;
    }

    /**
     * Finds the largest number in the array
     * 
     * @throws RuntimeException if array is empty
     * @return The largest number in the array
     */
    public int findMax() throws RuntimeException {
        if (isEmpty())
            throw new RuntimeException("Array is Empty.");

        int maxValue = 0;

        for (int i = 0; i < getSize(); i++) {
            if (array[i] >= maxValue) {
                maxValue = array[i];
            }
        }

        return maxValue;
    }

    /**
     * Returns the array as a formatted string [x, y, z]
     * 
     * @return A formatted string of the array values
     */
    public String toString() {

        StringBuilder newString = new StringBuilder();

        newString.append('[');
        if (isEmpty()) {
            return "[ ]";
        }

        for (int i = 0; i < getSize(); i++) {
            if (i == getSize() - 1) {
                newString.append(array[i]);
            } else {
                newString.append(array[i] + ", ");
            }
        }
        newString.append(']');

        return newString.toString();
    }

    /**
     * Compares two arrays of objects
     * 
     * @param obj the second object
     * @return returns true if arrays are the same, false if not
     */
    public boolean equals(DynamicArray obj) {
        if (getSize() != obj.getSize())
            return false;

        for (int i = 0; i < obj.getSize(); i++) {
            if (this.array[i] != obj.get(i))
                return false;
        }
        return true;
    }
}
