public class RightTriangle {
    
    //Values to represent each side of a triangle
    private double legOne;
    private double legTwo;
    
    
     /** 
     * No argument constructor RightTriangle() overrides the default Java contructor to set the length of the sides to 1
     */
    RightTriangle()
    {
        legOne = 1;
        legTwo = 1;
    }

    /** 
     * Argument constructor RightTriangle(double a, double b) accepts two triangle leg lengths as arguments
     * @param a The length of a side of the triangle
     * @param b The length of a side of the triangle
     * @throws IllegalArgumentException when one or both legs are set to 0 or negative numbers
     */
    RightTriangle(double a, double b) throws IllegalArgumentException
    { 
        if (a <= 0 || b <= 0)
        {
            throw new IllegalArgumentException();
        }

        legOne = a;
        legTwo = b;

    }


    /** 
     * Accessor method getLegA() accesses the value of legOne
     * @return The value of legOne
     */
    public double getLegA()
    {
        return legOne;
    }

     /** 
     * Accessor method getLegA() accesses the value of legOne
     * @return The value of legTwo
     */
    public double getLegB()
    {
        return legTwo;
    }

    /** 
     * Mutator method setLegA() sets the value of legOne
     * @param a The new value of legOne
     */
    public void setLegA(double a)
    {
        if (a <= 0)
        {
            throw new IllegalArgumentException();
        }

        legOne = a;
    }

    /** 
     * Mutator method setLegB() sets the value of legOne
     * @param a The new value of legTwo
     */
    public void setLegB(double a)
    {
        if (a <= 0)
        {
            throw new IllegalArgumentException();
        }

        legTwo = a;
    }


    /** 
     * Accessor method getHypotenuse() returns the length of the Hypotenuse
     * @return The calculated value of the hypotenuse
     */
    public double getHypotenuse()
    {
        return Math.sqrt((legOne * legOne) + (legTwo * legTwo));
    }

    /** 
     * Accessor method getArea() returns the area of the Triangle
     * @return The calculated value of the area
     */
    public double getArea()
    {
        return (.5) * legOne * legTwo;
    }


    /** 
     * Accessor method getPerimeter() returns the area of the Triangle
     * @return The calculated value of the area
     */
    public double getPerimeter()
    {
        return legOne + legTwo + getHypotenuse();
    }


    /** 
     * Method toString() returns the value of each leg in the string format
     * @return a String version including both triangle side values
     */
    public String toString ()
    {
        return "legA = " + legOne + ", " + "legB = " + legTwo;
    }


}
