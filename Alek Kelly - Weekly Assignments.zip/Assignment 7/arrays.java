public class arrays 
{
  public static void main(String[] args) 
  {
    int[] empty2 = {0, 0, 0, 0, 0};
    int[] empty3 = new int[5];


    System.out.println(empty2.length);
    System.out.println(empty3.length);
  }  
}
