
import static java.lang.System.in;

import java.util.Scanner;

/**
 *
 * @author Alek Kelly
 */
public class TwoProblems 
{

    public static void main(String[] args) 
    {
        
        // ******** Problem 1: Logic Problem ********************
        // This program has a logical error. Your goal is to fix it.
       
        
        double firstNumber; // to hold the first number
        double secondNumber; // to hold the second number
        double tempVar1; // to hold a temporary value

        // create scanner object to read input
        Scanner keyboard = new Scanner(System.in);

        // Prompt user to enter the first number.
        System.out.print("Enter the first number:");
        
        // input the first number
        firstNumber = keyboard.nextDouble();

        // Promt user to enter the second number.
        System.out.print("Enter the second number:");
        
        // input the second number
        secondNumber = keyboard.nextDouble();

        // Echo print the input.
        System.out.println("You input the numbers as " + firstNumber + " and " + secondNumber);

        // Makes the switch using a placeholder variable
        tempVar1 = firstNumber; //Assigns first number value to the temporary variable
        firstNumber = secondNumber; //Assigns second number value to firstNumber variable
        secondNumber = tempVar1; //Assigns temporary variable value to secondNumber
       

        // Output the values.
        System.out.println("After swapping, the values of the two numbers are " + firstNumber + " and " + secondNumber);

        //Closes the scanner to prevent a memory leak
        keyboard.close();

        /*
        
        ********* Problem 2: Circle Area Problem ***********
         Implement the following step-by-step plan:
         1. Declare double constant PI to hold 3.14
         2. Declare a double variable to store radius
         3. Declare a double variable to store area
         4. Prompt the user to enter radius.
         5. Input radius and store it in variable
         6. Calculate circle area. Find the formula on the web if you don't remember it
         7. Output the circle's radius and area values in user-friendly fashion

        */


        double piValue = Math.PI;   //Variable established to hold the value of PI
        double radiusValue;         //Variable established to hold the value of Radius
        double areaValue;           //Variable established to hold the value of the Area


        //Creates a scanner object to read input
        Scanner radius = new Scanner(in);
        
        //Prompts user for input
        System.out.println("Please enter the radius as a double: ");

        //Takes user input and assigns the value to radiusValue
        radiusValue = radius.nextDouble();

        //Calls calculateCicleArea to calculate and assign the area to areaValue
        areaValue = calculateCircleArea(piValue, radiusValue);

        //Tells the user the value of radiusValue
        System.out.println("The radius of the circle is " + radiusValue + " units.");
        
        //Tells the user the area of the circle
        System.out.println("The area of the circle is " + areaValue + " units.");

        //Closes the radius scanner to prevent memory leak
        radius.close();

        // ********* End of Circle Area Problem code area ***********

    }

    //This method calculates the area of the circle using the two variables passed in - the value of PI, and the radius of the circle.
    public static double calculateCircleArea(double x , double y)
    {
        return (x *(y * y)); //This formula is PI * radius^2
    }

}
