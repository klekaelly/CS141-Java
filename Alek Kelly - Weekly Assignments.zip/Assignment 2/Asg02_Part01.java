
/**
 *
 * @author Alexandra Vaschillo
 */
public class Asg02_Part01 {

  
    /**
     * Method checks if a triangle with given lengths of sides is a right triangle
     * @param side1 triangle side
     * @param side2 triangle side
     * @param side3 triangle side
     * @return true if the triangle is right, false if it is not
     */


    public static boolean isRightTri(int side1, int side2, int side3)
    {
        int c = 1; //Holds the largest value of the three inputted parameters. Important for the largest side length to be isolated on one side of the equation.
        int a = 1;  //Holds the other side length
        int b = 1;  //Holds the other side length


        /* Step 1: Determine the largest number and re-assign it */

        //If number 1 is the biggest, "c" is assigned that value and the number2 and number3 become "b" and "a"
        if ((side1 > side2) && (side1 > side3))
        {
            c = side1; //Assigns largest value to "c"
            a = side2; //Assigns other value to "a"
            b = side3; //Assigns other value to "b"
        }

        //If number 2 is the biggest, "c" is assigned that value and the number1 and number3 become "b" and "a"
        if ((side2 > side1) && (side2 > side3))
        {
            c = side2; //Assigns largest value to "c"
            a = side1; //Assigns other value to "a"
            b = side3; //Assigns other value to "b"
        }

        //If number 3 is the biggest, "c" is assigned that value and the number1 and number2 become "b" and "a"
        if ((side3 > side2) && (side3 > side1))
        {
            c = side3; //Assigns largest value to "c"
            a = side1; //Assigns other value to "a"
            b = side2; //Assigns other value to "b"
        } 


        /* Step 2: Use the Pythagorean theorem to determine whether the values represent a right triangle */

        if ( Math.pow(a,2) + Math.pow(b,2) == Math.pow(c,2) ) //If a^2 + b^2 = c^2, then we have a right triangle.
        {
            return true;
        } else {

        return false; //If a^2 + b^2 != c^2, then we do not have a right triangle.
        }

    }





    /**
     * The method takes hour, minute, and "am", "pm" components of the time stamp of the moment when car crosses the bridge and calculates the toll rate.
     * If any of the time stamp components are invalid, -1 is being returned as an error code.
     * @param hour hour component of the time stamp 
     * @param min minute component of the time stamp
     * @param amPm either string "am" or "pm", component of the time stamp
     * @return the toll rate  
     */
    public static double toll520Bridge(int hour, int min, String amPm) 
    {
        /* Declaration of Arrays to hold values */
        String[] timeOfDay = { "am", "pm" }; //Easy way to compare the amPm string to
        double[] tollCost = {1.25, 1.40, 2.05, 2.65}; //Easy way to store the toll amounts
        

        /* Verify that the user inputted values are valid inputs */

        //Verify that the hour is 1 - 12
        if (hour < 1 || 12 < hour )
        {
            return -1;
        }
        //Verify that the minutes are 0 - 59
        if (min > 59 || 0 > min)
        {
            return -1;
        }

        //Verify that the AM / PM is am or pm
        if (!amPm.equals(timeOfDay[0]) && !amPm.equals(timeOfDay[1]))
        {
            return -1;
        }


        /* Converts time entered into 0 - 23 indexed time system */
        
        //If it is PM and the input hour is 12, we should add 12 so it occupies slot 12 on our 0-23 military time format
        if (amPm.equals(timeOfDay[1])){
            if (hour != 12)
            {
                hour = hour + 12;
            }

        }
        //If it is AM and the input hour is 12, we should subtract 12 so it occupies slot 0 on our 0-23 military time format
        if (amPm.equals(timeOfDay[0])){
            if (hour == 12)
            {
                hour = hour - 12;
            }

        }


        /* These statements take the hour and use it to determine what the tollCost would be */

        //Midnight to 4:59 am, 11pm to 11:59pm 
        if (0 <= hour && hour <= 4 || 23 == hour)
        {
            return tollCost[0]; //Returns 1.25
        }
    
        //5 am to 7:59 am, 9pm to 10:59 pm
        if (5 <= hour && hour <= 7|| 21 <= hour && hour <= 22)
        {
            return tollCost[1]; //Returns 1.40
        }
    
        //8 am to 10:59 am, 6 pm to 8:59 pm
        if (8 <= hour && hour <= 10 || 18 <= hour && hour <= 20)
        {
            return tollCost[2]; //Returns 2.05
        }

        //11 am to 5:59 pm
        if (11 <= hour && hour <= 17)
        {
            return tollCost[3]; //Returns 2.65
        }
        
        
        return 0.00;
    }

    public static void testIsRightTri()
    {
        
         //*** Test 1 ***//
        if(isRightTri(3, 4, 5)) System.out.println("Test 1 for isRightTri() PASSED");
        else System.out.println("Test 1 for isRightTri() Failed");
   
        //*** Test 2 ***//     
        if(isRightTri(4, 5, 3)) System.out.println("Test 2 for isRightTri() PASSED");
        else System.out.println("Test 2 for isRightTri() Failed");
        
        //*** Test 3 ***//     
        if(isRightTri(5, 4, 3)) System.out.println("Test 3 for isRightTri() PASSED"); 
        else System.out.println("Test 3 for isRightTri() Failed");
        
        //*** Test 4 ***//     
        if(isRightTri(3, 5, 4)) System.out.println("Test 4 for isRightTri() PASSED");
        else System.out.println("Test 4 for isRightTri() Failed");
        
        //*** Test 5 ***//     
        if(isRightTri(5, 3, 4)) System.out.println("Test 5 for isRightTri() PASSED");
        else System.out.println("Test 5 for isRightTri() Failed");
        
        //*** Test 6 ***//     
        if(isRightTri(4, 3, 5)) System.out.println("Test 6 for isRightTri() PASSED"); 
        else System.out.println("Test 6 for isRightTri() Failed");
        
        //*** Test 7 ***//     
        if(!isRightTri(4, 4, 5)) System.out.println("Test 7 for isRightTri() PASSED"); 
        else System.out.println("Test 7 for isRightTri() Failed");
    }
    
    public static void testToll520Bridge()
    {
        //*** Test 1 ***//  
        if(toll520Bridge(5, 20, "aa")==-1) System.out.println("Test 1 for toll520Bridge() PASSED");
        else System.out.println("Test 1 for toll520Bridge() Failed");
        
        //*** Test 2 ***//  
        if(toll520Bridge(5, 65, "am")==-1) System.out.println("Test 2 for toll520Bridge() PASSED");
        else System.out.println("Test 2 for toll520Bridge() Failed");
        
        //*** Test 3 ***//  
        if(toll520Bridge(15, 15, "am")==-1) System.out.println("Test 3 for toll520Bridge() PASSED");
        else System.out.println("Test 3 for toll520Bridge() Failed");
        
        //*** Test 4 ***//  
        if(toll520Bridge(12, 0, "am")==1.25 && toll520Bridge(4, 59, "am")==1.25 && toll520Bridge(3, 35, "am")==1.25) System.out.println("Test 4 for toll520Bridge() PASSED");
        else System.out.println("Test 4 for toll520Bridge() Failed");
        
        //*** Test 5 ***//  
        if(toll520Bridge(5, 0, "am")==1.4 && toll520Bridge(7, 59, "am")==1.4 && toll520Bridge(6, 03, "am")==1.4) System.out.println("Test 5 for toll520Bridge() PASSED");
        else System.out.println("Test 5 for toll520Bridge() Failed");
        
        //*** Test 6 ***//  
        if(toll520Bridge(8, 0, "am")==2.05 && toll520Bridge(10, 59, "am")==2.05 && toll520Bridge(9, 15, "am")==2.05) System.out.println("Test 6 for toll520Bridge() PASSED");
        else System.out.println("Test 6 for toll520Bridge() Failed");
        
        //*** Test 7 ***//  
        if(toll520Bridge(11, 0, "am")==2.65 && toll520Bridge(4, 59, "pm")==2.65&& toll520Bridge(3, 55, "pm")==2.65) System.out.println("Test 7 for toll520Bridge() PASSED");
        else System.out.println("Test 7 for toll520Bridge() Failed");
        
        //*** Test 8 ***//  
        if(toll520Bridge(6, 0, "pm")==2.05 && toll520Bridge(8, 59, "pm")==2.05 && toll520Bridge(6, 15, "pm")==2.05) System.out.println("Test 8 for toll520Bridge() PASSED");
        else System.out.println("Test 8 for toll520Bridge() Failed");
        
        //*** Test 9 ***//  
        if(toll520Bridge(9, 0, "pm")==1.4 && toll520Bridge(10, 59, "pm")==1.4 && toll520Bridge(9, 3, "pm")==1.4) System.out.println("Test 9 for toll520Bridge() PASSED");
        else System.out.println("Test 9 for toll520Bridge() Failed");
        
        //*** Test 10 ***//  
        if(toll520Bridge(11, 0, "pm")==1.25 && toll520Bridge(11, 59, "pm")==1.25 && toll520Bridge(11, 40, "pm")==1.25) System.out.println("Test 10 for toll520Bridge() PASSED");
        else System.out.println("Test 10 for toll520Bridge() Failed");
    }
    
 
     /** Method main()contains all the tests 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
  
        testIsRightTri();
        testToll520Bridge();
        
    }
    
}
