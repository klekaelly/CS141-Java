package Final;

/*  B  */
import java.io.*;
import java.util.*;

/**
 * 
 * @author Alek Kelly
 *
 */

public class AllStaticMethods {

	/**
	 * Method prints a pattern into the provided filename and is controlled by num
	 * 
	 * @param filename The name of the file to be written to
	 * @param num      The height of the pattern
	 * @throws IOException              when file cannot be found
	 * @throws IllegalArgumentException when num is less than or equal to 0
	 */
	public static void problem01(String fileName, int num) throws IOException // , IllegalArgumentException
	{

		if (num <= 0) {
			throw new IllegalArgumentException();
		}

		//I know it's complicated, but it wasn't a priority to refactor this code
		try (PrintWriter myFile = new PrintWriter(fileName)) {
			for (int i = 0; i < num; i++) {

				if (num % 2 == 0) {

					if (i % 2 == 1) {
						for (int j = 0; j <= i; j++) {
							myFile.print("*");
						}
					}

					if (i % 2 == 0) {
						for (int j = 0; j <= i; j++) {
							myFile.print("-");
						}
					}
				}

				if (num % 2 == 1) {
					if (i % 2 == 1) {
						for (int j = 0; j <= i; j++) {
							myFile.print("-");
						}
					}

					if (i % 2 == 0) {
						for (int j = 0; j <= i; j++) {
							myFile.print("*");
						}
					}

				}

				myFile.println("");

			}

		} catch (IOException e) {

			throw new IOException("Output file not found.");
		}
	}

	/**
	 * Method reads numbers from a file and reorganizes the numbers within the file based upon the provided k value
	 * @param fileName The name of the file being read and written to
	 * @param k The number each value in the file will be evaluated against
	 * @throws IOException When file cannot be found
	 */
	public static void problem02(String fileName, int k) throws IOException
	{
		ArrayList<Integer> temp = new ArrayList<>();
		ArrayList<Integer> temp2 = new ArrayList<>();

		File myFile = new File(fileName);

		if (!myFile.exists()) {
			throw new IOException();
		}

		try (Scanner inputFile = new Scanner(myFile)) {

			while (inputFile.hasNextLine()) {

				String nextLine = inputFile.nextLine();
				int currentInteger = Integer.parseInt(nextLine);

				if (currentInteger <= k) {
					temp.add(currentInteger);
				}

				if (currentInteger > k) {
					temp2.add(currentInteger);
				}

			}

			for (int i = 0; i < temp2.size(); i++) {
				temp.add(temp2.get(i));
			}

		} catch (IOException e) {
			throw new IOException("Input file not found.");
		}

		try (PrintWriter myFile2 = new PrintWriter(fileName)) {
			for (int i : temp) {
				myFile2.println(i);
			}

		} catch (IOException e) {

			throw new IOException("Output file not found.");
		}

	}

	/**
	 * Returns the number of occurances of class x in an array of classes 
	 * @param array The array of classes
	 * @param x The array to look for
	 * @return The number of occurances of X in array
	 */
	public static int problem03(ClassA[] array, ClassA x) 
	{
		int count = 0;
		int matches = 0;

		if (array == null) return 0;

		for (ClassA i : array) 
		{
			if (i.getClass().equals(x))
			{
				matches++;
			}
			
		}

		return matches;
	}

}
