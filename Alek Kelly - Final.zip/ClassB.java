package Final;

/*  B  */

import java.util.ArrayList;

/**
 * 
 * @author Your Name here!
 *
 */

public class ClassB {

	private ArrayList<String> first;
	private int second;
	
	public ClassB()
	{
		first = new ArrayList<String>(1);
		second = 0;
	}
	
	/**
	 * This is a copy constructor that provides a copy of the original object
	 * @param obj The object instance to be copied
	 */
	public ClassB(ClassB obj)
	{
		if (obj == null)
            throw new IllegalArgumentException();

			this.second = obj.second;

		ArrayList copy = new ArrayList<String>();
        
        for (int i = 0; i < obj.first.size(); i++) {
			copy.add(obj.first.get(i));
		}
		
        this.first = copy;

	}
	
	public void push(String n)
	{
		first.add(n);
		second++;
	}
	
	public String toString()
	{
		if (second == 0) return "{first=[]; second=0}";
      else return "{first="+first.toString()+"; second="+second+"}";
	}
	
	
	public ArrayList<String> getFirst()
	{
		ArrayList<String> copy = new ArrayList<>();

		for (String string : first) {
			copy.add(string);
		}


		return copy;
	}
}
