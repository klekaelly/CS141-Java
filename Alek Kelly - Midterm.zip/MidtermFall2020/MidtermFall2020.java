
/**
 *
 * @author Alek Kelly
 */
import java.io.*;
import java.util.Scanner;
import java.util.*;
import java.util.ArrayList;

public class MidtermFall2020 {

	/**
	 * Problem 1 takes three numbers and returns whether the third number is within
	 * the range of the first two
	 * 
	 * @param a is the value of the left bounding range
	 * @param b is the value of the right bounding range
	 * @return true if c is within the range of a, b and false if c is not within
	 *         the range of a, b
	 */
	public static boolean problem01(double a, double b, double c) {
		if (a < b) {
			if (c >= a && c <= b) {
				return true;
			} else {
				return false;
			}
		}
		if (b < a) {
			if (c >= b && c <= a) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	/**
	 * Problem 2 performs input validation on three integers, passes them into
	 * problem01 and displays the result.
	 */
	public static void problem02() {

		// Holds three user input values
		int a = 0;
		int b = 0;
		int c = 0;
		Scanner keyboard = new Scanner(System.in);

		while (1 != 2) {
			System.out.println("Please enter a positive integer: ");
			int userChoice = keyboard.nextInt();

			if (userChoice > 0) {
				System.out.println("Input saved.");
				a = userChoice;
				break;
			}
			if (userChoice < 0) {
				System.out.println("Invalid Input. Please try again: ");

			}
		}
		while (1 != 2) {
			System.out.println("Please enter another positive integer: ");
			int userChoice = keyboard.nextInt();

			if (userChoice > 0) {
				System.out.println("Input saved.");
				b = userChoice;
				break;
			}
			if (userChoice < 0) {
				System.out.println("Invalid Input. Please try again: ");
			}
		}
		while (1 != 2) {
			System.out.println("Please enter another positive integer: ");
			int userChoice = keyboard.nextInt();

			if (userChoice > 0) {
				System.out.println("Input saved.");
				c = userChoice;
				break;
			}
			if (userChoice < 0) {
				System.out.println("Invalid Input. Please try again: ");
			}
		}

		if (problem01(a, b, c) == false) {
			System.out.println("The number " + (double) c + " does not belong to the range [" + (double) a + ", "
					+ (double) b + "]");
		}
		if (problem01(a, b, c) == true) {
			System.out.println(
					"The number " + (double) c + " belongs to the range [" + (double) a + ", " + (double) b + "]");
		}
	}

	/**	
	 * Problem 3 takes a file name and outputs a pattern of values to the file
	 * @param fileName Name of the file
	 * @param digit1 The first number representing a digit in a pair
	 * @param digit2 The second number representing a digit in a pair
	 * @throws IllegalArgumentException when any of the two parameters are negative.
	 * @throws IOException when the file can't be found or written to
	 */
	public static void problem03(String fileName, int digit1, int digit2) throws IOException 
	{

		if (digit1 >= 10 || digit2 >= 10 || digit1 < 0 || digit2 < 0)
		{
			throw new IllegalArgumentException();
		}
	   
		
        try
        {

		FileWriter fwriter = new FileWriter(fileName, false);	
		PrintWriter outputFile = new PrintWriter(fwriter);
	
		String s1 = Integer.toString(digit1); 
		String s2 = Integer.toString(digit2); 
		String s = s1 + s2; 

		int c = Integer.parseInt(s); 

		
		outputFile.println(digit1);

		if (digit1 > digit2) {
			for (int i = digit1; i < digit2; i++) {
				int temp = c + 10;
				outputFile.print(temp);
			}
		}
		if (digit2 > digit1) {
			for (int i = digit2; i < digit1; i++) {
				int temp = c - 10;
				outputFile.print(temp);
			}
		}

        } catch (IOException  e)
        {
            throw new IOException("An IO Exception occured!");
        }

	}   
	
	
	/**	
	 * Problem 4 takes two numbers and checks to see if the sum of the digits of both integers are the same
	 * @param num1 The first number
	 * @param num2 The second number
	 * @throws IllegalArgumentException when any of the two parameters are negative.
	 * @return a Boolean value representing whether the sum of the digits is the same
	 */
	public static boolean problem04(int num1, int num2) {


		int n = num1;
		int x = num2;
		int sum = 0;
		int sum2 = 0;

		if (num1 < 0)
		{
			throw new IllegalArgumentException();
		}
		if (num2 < 0)
		{
			throw new IllegalArgumentException();
		}

		for (sum = 0; n != 0; n /= 10) {
			sum += n % 10;
		}

		for (sum2 = 0; x != 0; x /= 10) {
			sum2 += x % 10;
		}

		if (sum == sum2)
		{
			return true;
		} else 
		{
			return false;
		}
	}

	/**
	 * Method runs all test cases for problem01() method
	 * 
	 * @param outputStream - output stream, used to print into the screen
	 * @return number of points the problem is worth if all the tests ran
	 *         successfully. If any of the tests failed the method returns a 0.
	 */
	public static int testsProblem01(PrintStream outputStream) {
		int expectedCount = 2;
		int count = 0;
		int pointValue = 25;

		outputStream.println("\r\n----Tests for problem01()----\r\n");
		// Test #1
		if (problem01(1, 3, 2) == true && problem01(1, 2, 2) == true && problem01(1, 2, 1) == true
				&& problem01(-2, -1, -1) == true && problem01(1, 3, 4) == false && problem01(1, 3, 0) == false) {
			outputStream.printf("%-50s%-10s\r\n", "problem01() TEST 01 - regular range", "PASSED");
			count++;
		} else
			outputStream.printf("%-50s%-10s\r\n", "problem01() TEST 01 - regular range", "FAILED");

		// Test #2
		if (problem01(5, 3, 4) == true && problem01(4, 3, 4) == true && problem01(4, 3, 3) == true
				&& problem01(-5, -3, -4) == true && problem01(5, 3, 6) == false && problem01(5, 3, 2) == false) {
			outputStream.printf("%-50s%-10s\r\n", "problem01() TEST 02 - inverted range", "PASSED");
			count++;
		} else
			outputStream.printf("%-50s%-10s\r\n", "problem01() TEST 02 - inverted range", "FAILED");

		if (count == expectedCount)
			return pointValue;
		else
			return 0;

	}

	/**
	 * Method runs all test cases for problem03() method The method generates a
	 * number of test case files. Please see those files to make sure your file
	 * output format matches the output format in test files
	 * 
	 * @param outputStream - output stream, used to print into the screen
	 * @return number of points the problem is worth if all the tests ran
	 *         successfully. If any of the tests failed the method returns a 0.
	 */
	public static int testsProblem03(PrintStream outputStream) {
		int expectedCount = 6;
		int count = 0;
		int pointValue = 25;
		// Data needed for the test cases is built here
		outputStream.println("\n--------- problem03() Tests ---------");

		String[] testOut0 = { "0 " };
		String[] testOut1 = { "27 37 47 57 67 77 " };
		String[] testOut2 = { "72 62 52 42 32 22 " };
		String[] testOut3 = { "19 29 39 49 59 69 79 89 99 " };
		String[] testOut4 = { "53 43 33 " };
		String[] testOut5 = { "33 " };

		// building test case files
		try {
			buildTestFile("testCaseOut0.txt", testOut0);
			buildTestFile("testCaseOut1.txt", testOut1);
			buildTestFile("testCaseOut2.txt", testOut2);
			buildTestFile("testCaseOut3.txt", testOut3);
			buildTestFile("testCaseOut4.txt", testOut4);
			buildTestFile("testCaseOut5.txt", testOut5);
		} catch (IOException e) {
			System.out.println("Trouble with file IO when building test case files");
		}

		try {
			// --- Test 1 ---//

			problem03("test00.txt", 0, 0);
			problem03("test01.txt", 2, 7);
			problem03("test02.txt", 7, 2);
			problem03("test03.txt", 1, 9);
			problem03("test04.txt", 5, 3);
			problem03("test05.txt", 3, 3);
			// comparing resulting files
			if (areEqualFiles("testCaseOut0.txt", "test00.txt") && areEqualFiles("testCaseOut1.txt", "test01.txt")
					&& areEqualFiles("testCaseOut2.txt", "test02.txt")
					&& areEqualFiles("testCaseOut3.txt", "test03.txt")
					&& areEqualFiles("testCaseOut4.txt", "test04.txt")
					&& areEqualFiles("testCaseOut5.txt", "test05.txt")) {
				outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 01 - regular functionality", "PASSED");
				count++;
			} else
				outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 01 - regular functionality", "FAILED");

			// --- Test 2 ---//
			try {
				problem03("someFile.txt", 30, 3);
				outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 02 IllegalArgumentException first non-digit",
						"FAILED");

			} catch (IllegalArgumentException e) {
				outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 02 IllegalArgumentException first non-digit",
						"PASSED");
				count++;
			}

			// --- Test 3 ---//
			try {
				problem03("someFile.txt", -1, 3);
				outputStream.printf("%-80s%-10s\r\n",
						"problem03() TEST 03 IllegalArgumentException first negative digit", "FAILED");

			} catch (IllegalArgumentException e) {
				outputStream.printf("%-80s%-10s\r\n",
						"problem03() TEST 03 IllegalArgumentException first negative digit", "PASSED");
				count++;
			}

			// --- Test 4 ---//
			try {
				problem03("someFile.txt", 1, 33);
				outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 04 IllegalArgumentException second non-digit",
						"FAILED");

			} catch (IllegalArgumentException e) {
				outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 04 IllegalArgumentException second non-digit",
						"PASSED");
				count++;
			}

			// --- Test 5 ---//
			try {
				problem03("someFile.txt", 1, -3);
				outputStream.printf("%-80s%-10s\r\n",
						"problem03() TEST 05 IllegalArgumentException second negative digit", "FAILED");

			} catch (IllegalArgumentException e) {
				outputStream.printf("%-80s%-10s\r\n",
						"problem03() TEST 05 IllegalArgumentException second negative digit", "PASSED");
				count++;
			}
			// --- Test 6 ---//

			try {
				problem03("some/File.txt", 2, 9);
				outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 06 - IOException", "FAILED");

			} catch (IOException e) {
				outputStream.printf("%-80s%-10s\r\n", "problem03() TEST 06 - IOException", "PASSED");
				count++;
			}
		}

		catch (IOException e) {
			System.out.println("Trouble with file IO when running tests");
		}
		if (count == expectedCount)
			return pointValue;
		else
			return 0;

	}

	/**
	 * Runs all tests for problem04() method
	 * 
	 * @param outputStream - output stream, used to print into the screen
	 * @return number of points the problem is worth if all the tests ran
	 *         successfully. If any of the tests failed the method returns a 0.
	 */
	public static int testsProblem04(PrintStream outputStream) {
		int expectedCount = 3;
		int count = 0;
		int pointValue = 25;

		outputStream.println("\r\n----Tests for problem04()----\r\n");
		// Test #1
		if (problem04(111, 3) == true && problem04(123, 24) == true && problem04(321, 1113) == true
				&& problem04(0, 0) == true && problem04(123, 2567) == false) {
			outputStream.printf("%-50s%-10s\r\n", "problem04() TEST 01 - basic functionality", "PASSED");
			count++;
		} else
			outputStream.printf("%-50s%-10s\r\n", "problem04() TEST 01 - basic functionality", "FAILED");

		// Test #2
		try {
			problem04(-11, 1);
			outputStream.printf("%-50s%-10s\r\n", "problem04() TEST 02 - IllegalArgumentException", "FAILED");

		} catch (IllegalArgumentException e) {
			outputStream.printf("%-50s%-10s\r\n", "problem04() TEST 02 - IllegalArgumentException", "PASSED");
			count++;
		}
		// Test #3
		try {
			problem04(11, -1);
			outputStream.printf("%-50s%-10s\r\n", "problem04() TEST 03 - IllegalArgumentException", "FAILED");

		} catch (IllegalArgumentException e) {
			outputStream.printf("%-50s%-10s\r\n", "problem04() TEST 03 - IllegalArgumentException", "PASSED");
			count++;
		}
		if (count == expectedCount)
			return pointValue;
		else
			return 0;

	}

	/**
	 * Compares content of two files and returns true if content is identical, false
	 * if not
	 * 
	 * @param fileName1 name of first file to be compared
	 * @param fileName2 name of second file to be compared
	 * @return true if the files are identical, false if not
	 * @throws IOException thrown when files fail to open for reading / writing
	 */
	public static boolean areEqualFiles(String fileName1, String fileName2) throws IOException {
		FileReader file1 = new FileReader(fileName1);
		FileReader file2 = new FileReader(fileName2);
		Scanner input1 = new Scanner(file1);
		Scanner input2 = new Scanner(file2);
		while (input1.hasNext() && input2.hasNext()) {
			String s1 = input1.nextLine().trim();
			String s2 = input2.nextLine().trim();
			if (!s1.equals(s2)) {
				input1.close();
				input2.close();
				return false;
			}
		}
		boolean res;
		if (!input1.hasNext() && !input2.hasNext())
			res = true;
		else
			res = false;
		input1.close();
		input2.close();
		return res;
	}

	/**
	 * Builds a file with a given name with a content defined by an array of objects
	 * that are printed to the file as strings, one string per line
	 * 
	 * @param fileName name of file to write to
	 * @param testCase array of objects to print into file in string format
	 * @throws IOException throws exception when file fails to open for writing or
	 *                     writing fails
	 */
	public static void buildTestFile(String fileName, Object[] testCase) throws IOException {
		FileWriter file = new FileWriter(fileName);
		PrintWriter outputFile = new PrintWriter(file);

		for (Object a : testCase) {
			outputFile.println(a);
		}
		outputFile.close();
	}

	public static void main(String[] args) {
		int total = 0;
		int expectedTotal = 75;
		PrintStream out = System.out;
		int tmp = 0;

		tmp = testsProblem01(out);
		out.printf("\nYou earned %d out of %d points for problem01()\n", tmp, 25);
		total += tmp;

		out.printf("\nProblem02 call follows (test manually) -----------------------\n");

		problem02(); // this problem involves user I/O and does not have any unit tests.
						// please make sure to test it manually
		out.printf("\nEnd of call to problem02 -----------------------\n");

		tmp = testsProblem03(out);
		out.printf("\nYou earned %d out of %d points for problem03()\n", tmp, 25);
		total += tmp;
		tmp = testsProblem04(out);
		out.printf("\nYou earned %d out of %d points for problem04()\n", tmp, 25);
		total += tmp;
		out.printf("\nYou earned %d out of %d points for problems 1, 3, and 4\n", total, 75);
	}

}
