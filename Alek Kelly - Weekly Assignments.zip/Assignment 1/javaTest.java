public class javaTest {
    public static void main(String[] args) {
        
        


        /*how to "round" to two decimal places */

        double num = 12345.6789;
        int d = 5;
        int a = 5;
        int b = 506;
        String str = "hi there!";

        System.out.printf("The numbers are %.2f and %d", num, d);
        System.out.printf("|\n%5d|\n|%5d|\n", b, a); //Alligning these numbers
    }
}
