

/**
 *
 * @author Alexandra Vaschillo
 */



public class Assignment05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {   
        int total = 0;
        total += allTestsPointClass();
        total += allTestsRightTriangleClass();
        total += allTestsMyIntegerClass();
        System.out.println("You earned "+ total + " out of 100 points for the assignment");
        
    }
    public static int allTestsPointClass()
    { 
        int total = 0;
        int expectedTotal = 30;
        System.out.println("\n----Tests for Point Class----\n");
        total+= test01PointClass();
        total+= test02PointClass();
        total+= test03PointClass();
        System.out.printf("You earned %d out of %d points for Point class part of the assignment\n", total, expectedTotal);
        return total;   
    }
    public static int allTestsRightTriangleClass()
    { 
       int total = 0;
       int expectedTotal = 30;
        System.out.println("\n----Tests for RightTriangle Class----\n");
        total+= test01TriangleClass();
        total+= test02TriangleClass();
        total+= test03TriangleClass();
        System.out.printf("You earned %d out of %d points for RigthTriangle class part of the assignment\n", total, expectedTotal);
        return total;   
    }
    public static int allTestsMyIntegerClass()
    { 
        int total = 0;
        int expectedTotal = 40;
        System.out.println("\n----Tests for MyInteger Class----\n");
        total+= test01MyIntegerClass();
        total+= test02MyIntegerClass();
        total+= test03MyIntegerClass();
        System.out.printf("You earned %d out of %d points for MyInteger class part of the assignment\n", total, expectedTotal);
        return total;   
    }
    public static int test01PointClass()
    {
        
        double x1 = 33.1,  y1 = 44; // point  coordinates for setting
        double xx1 = 33.1, yy1= 44; //- expected point coordinates
 
        int count = 0;
        int expectedCount = 1;
        int points = 10;
//Test #1  
        Point point1 = new Point(); 
        point1.setX(x1);
        point1.setY(y1);
        if(point1.getX()==xx1 && point1.getY()== yy1) 
        {
            System.out.printf("%-80s%-10s\n", "Point TEST 01: Test for set and get methods",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Point TEST 01: Test for set and get methods",  "FAILED");
        
        if(count==expectedCount) return points;
        else return points;
    }
    
    public static int test02PointClass()
    {    
        double x2 = -925.5, y2 = 6; // point2  coordinates
        double xx1 = 1, yy1= 1; //- expected point1 default coordinates
        double xx2 = -925.5, yy2= 6; //- expected point2  coordinates
        int count = 0;
        int expectedCount = 2;
        int points = 10;
//Test #1
        Point point1 = new Point(); 
        if(point1.getX()==xx1 && point1.getY()==yy1) 
        {
            System.out.printf("%-80s%-10s\n", "Point TEST 02: Test for non-argument constuctor",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Point TEST 02: Test for non-argument constuctor",  "FAILED");
//Test #2        
        Point point2 = new Point(x2, y2); 
        if(point2.getX()==xx2 && point2.getY()==yy2) 
        {
            System.out.printf("%-80s%-10s\n", "Point TEST 02: Test for constructor with parameters",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Point TEST 02: Test for constructor with parameters",  "FAILED");
        if(count==expectedCount) return points;
        else return 0;
    }
    /**
     * 
     * @return 
     */
    public static int test03PointClass()
    {
        double x1  = 125, y1 = 25; //  - original point coordinates
        double dx1 = 30, dy1 = -5; // - how the point moved
        double xx1 = 155, yy1 = 20; //- point after movement
        double rx1 = 20, ry1= -155; //- point after rotation
        int expectedCount = 2;
        int points = 10;
        int count = 0;
        Point point1 = new Point(); 
        point1.setX(x1);
        point1.setY(y1);
//Test #1          
        point1.move(dx1, dy1);
           
        if(point1.getX()==xx1 && point1.getY()==yy1) 
        {
            System.out.printf("%-80s%-10s\n", "Point TEST 03: Test for move() method",  "PASSED");
            count++;
        }
        else   System.out.printf("%-80s%-10s\n", "Point TEST 03: Test for move() method",  "FAILED");
 //Test #2       
        point1.rotate();

        if(point1.getX()==rx1 && point1.getY()==ry1) 
        {
            System.out.printf("%-80s%-10s\n", "Point TEST 03: Test for rotate() method",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Point TEST 03: Test for rotate() method",  "FAILED");
        
        if(count==expectedCount) return points;
        else return 0;
    }
    
    // set, get, throwing exceptions
    
    public static int test01TriangleClass()
    {
        
        double a1 = 10.1, b1 = 15.1; // legs for the set  method tests
        double aa1 = 10.1, bb1 = 15.1; // expected values for set method tests
        
        double a2 = -5, b2 = -5; // values for testting exceptions
        
        int expectedCount = 3;
        int points = 10;
        int count = 0;
//Test #1          
        RightTriangle tri1 = new RightTriangle();
        tri1.setLegA(a1);
        tri1.setLegB(b1);
        if(tri1.getLegA()==aa1 && tri1.getLegB()== bb1) 
        {
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 01: Test for set and get methods",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Right Triangle TEST 01: Test for set and get methods",  "FAILED");
 //Test #2  
        try
        {
            tri1.setLegA(a2);
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 01: Test for setLegA and exception it must throw",  "FAILED");
        }
        catch (IllegalArgumentException e)
        {
             System.out.printf("%-80s%-10s\n", "Right Triangle TEST 01: Test for setLegA and exception it must throw",  "PASSED");
             count++;
        }
 //Test #3
        try
        {
            tri1.setLegB(b2);
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 01: Test for setLegB and exception it must throw",  "FAILED");
        }
        catch (IllegalArgumentException e)
        {
             System.out.printf("%-80s%-10s\n", "Right Triangle TEST 01: Test for setLegB and exception it must throw",  "PASSED");
             count++;
        }
        if(count==expectedCount) return points;
        else return 0;
    }
    // constructors and exceptions
    public static int test02TriangleClass()
    {
        
        double a1 = 10.5, b1 = 15.3; // legs for constructor with parameters
        double aa1 = 10.5, bb1 = 15.3; // expected values to be set by constructor
        
        double aa2 = 1, bb2 = 1; // values for testting default constructor
        
        double a3 = -51, b3 = -8; // values for testing exceptions
        
        int expectedCount = 4;
        int points = 10;
        int count = 0;
 //Test #1       
        RightTriangle tri1 = new RightTriangle(a1, b1);
  
        if(tri1.getLegA()==aa1 && tri1.getLegB()== bb1) 
        {
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 02: Test for constuctor with parameters",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Right Triangle TEST 02: Test for constuctor with parameters",  "FAILED");
//Test #2        
        RightTriangle tri2 = new RightTriangle();
  
        if(tri2.getLegA()==aa2 && tri2.getLegB()== bb2) 
        {
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 02: Test for no-argument constuctor",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Right Triangle TEST 02: Test for no-argument constuctor",  "FAILED");
//Test #3        
        try
        {
            tri1.setLegA(a3);
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 02: Test for constructor and exception it must throw",  "FAILED");
        }
        catch (IllegalArgumentException e)
        {
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 02: Test for constructor and exception it must throw",  "PASSED");
            count++;
        }
//Test #4
        try
        {
            tri1.setLegB(b3);
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 02: Test for constructor and exception it must throw",  "FAILED");
        }
        catch (IllegalArgumentException e)
        {
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 02: Test for constructor and exception it must throw",  "PASSED");
            count++;
        }
        if(count==expectedCount) return points;
        else return 0;
    }
    // area, hypotenuse, perimeter, toString()
    public static int test03TriangleClass()
    {      
        double a1 = 3, b1 = 4; // legs 
        double hyp = 5;// expected hypotenuse 
        double perim = 12; // expected perimeter
        double area = 6; // expected area
        String str = "legA = 3.0, legB = 4.0"; // expected toString() result
        
        
        int expectedCount = 2;
        int points = 10;
        int count = 0;
        
        RightTriangle tri1 = new RightTriangle();
        tri1.setLegA(a1);
        tri1.setLegB(b1);
  
        if(tri1.getArea() == area && tri1.getHypotenuse() == hyp && tri1.getPerimeter()==perim) 
        {
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 03: Test for area, hypotenuse, and perimeter calculations",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Right Triangle TEST 03: Test for area, hypotenuse, and perimeter calculations",  "FAILED");
   
        if(tri1.toString().equals(str)) 
        {
            System.out.printf("%-80s%-10s\n", "Right Triangle TEST 03: Test for toString()",  "PASSED");
            count++;
        }
        else  System.out.printf("%-80s%-10s\n", "Right Triangle TEST 03: Test for toString()",  "FAILED");

        if(count==expectedCount) return points;
        else return 0;
    }
    
    public static int test01MyIntegerClass()
    { 
        int a = 55;
        int b = 102;
        int prime = 97;
        
        int expectedCount = 3;
        int points = 10;
        int count = 0;
 //Test #1       
        MyInteger num1 = new MyInteger(a);
        if(num1.toInteger()==a)
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 01: Test for constuctor",  "PASSED");
            count++; 
        }
        else  System.out.printf("%-80s%-10s\n", "MyInteger TEST 01: Test for constuctor",  "FAILED");
  //Test #2       
        MyInteger num2 = new MyInteger(b);
        
        if(!num1.isEven()&& num1.isOdd()&& num2.isEven() && !num2.isOdd())
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 01: Test for isEven() and isOdd()",  "PASSED");
            count++; 
        }
        else   System.out.printf("%-80s%-10s\n", "MyInteger TEST 01: Test for isEven() and isOdd()",  "FAILED");
  //Test #3           
        MyInteger num3 = new MyInteger(prime);
        if(num3.isPrime() && !num2.isPrime() && !num1.isPrime())
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 01: Test for isPrime()",  "PASSED");
            count++; 
        }
        else  System.out.printf("%-80s%-10s\n", "MyInteger TEST 01: Test for isPrime()",  "FAILED");
        if(count==expectedCount) return points;
        else return 0;
    }
    
    public static int test02MyIntegerClass()
    { 
        int a = 103;
        int b = 500;
        int prime = 919;
        
        int expectedCount = 3;
        int points = 10;
        int count = 0;
//Test #1          
        if(!MyInteger.isEven(a)&& MyInteger.isOdd(a)&& MyInteger.isEven(b) && !MyInteger.isOdd(b))
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 02: Test for static isEven() and static isOdd()",  "PASSED");
            count++; 
        }
        else  System.out.printf("%-80s%-10s\n", "MyInteger TEST 02: Test for static isEven() and static isOdd()",  "FAILED");
//Test #2          
        if(MyInteger.isPrime(prime) && MyInteger.isPrime(a) && !MyInteger.isPrime(b))
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 02: Test for static isPrime()",  "PASSED");
            count++; 
        }
        else  System.out.printf("%-80s%-10s\n", "MyInteger TEST 02: Test for static isPrime()",  "FAILED");
//Test #3        
        MyInteger num1 = new MyInteger(a);
        MyInteger num2 = new MyInteger(a);
        
        if(num1.equals(a) && num1.equals(num2))
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 02: Test for both isEquals() methods",  "PASSED");
            count++; 
        }
        else  System.out.printf("%-80s%-10s\n", "MyInteger TEST 02: Test for both isEquals() methods",  "FAILED");
        
        if(count==expectedCount) return points;
        else return 0;
    }
    public static int test03MyIntegerClass()
    { 
      
        int expectedCount = 6;
        int points = 20;
        int count = 0;
//Test #1       
       if(MyInteger.parseInt("2147483647") == 2147483647 && MyInteger.parseInt("12") == 12 && MyInteger.parseInt("0") == 0)
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() with valid positive values",  "PASSED");
            count++; 
        }
        else  System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() with valid positive values",  "FAILED");  
//Test #2       
       if(MyInteger.parseInt("-54321") == -54321 && MyInteger.parseInt("-2147483648") == -2147483648 && MyInteger.parseInt("-3") == -3)
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() with valid negative values",  "PASSED");
            count++; 
        }
        else System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() with valid negative values",  "FAILED");
//Test #3
       try // overflow detection test
        {
            int k = MyInteger.parseInt("2147483648");
             System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() overflow",  "FAILED");
        }
        catch(IllegalArgumentException e)
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() overflow",  "PASSED");
            count++;
        }
//Test #4        
        try // underflow detection test
        {
            int k = MyInteger.parseInt("-2147483649");
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() underflow",  "FAILED"); 
        }
        catch(IllegalArgumentException e)
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() underflow",  "PASSED");
            count++;
        }
//Test #5
        try // non-digit characters detection test
        {
            int k = MyInteger.parseInt("4a5");
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() invalid digits",  "FAILED");
        }
        catch(IllegalArgumentException e)
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() invalid digits",  "PASSED");
            count++;
        }
//Test #6
        try // non-digit characters detection test (special case)
        {
            int k = MyInteger.parseInt("-");
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() invalid digits (just '-')",  "FAILED");
        }
        catch(IllegalArgumentException e)
        {
            System.out.printf("%-80s%-10s\n", "MyInteger TEST 03: Test for parseInt() invalid digits (just '-')",  "PASSED");
            count++;
        }
        if(count==expectedCount) return points;
        else return 0;
    }
}
