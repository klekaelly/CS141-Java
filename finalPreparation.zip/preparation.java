package finalPreparation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class preparation
{
    public static void main(String[] args)
    {
        int digit = 5; //Changing this number and will count the number of occurances in the sequence
        String inputFile = "input.txt";
        String outputFile = "output.txt";
        ArrayList<Integer> storage = new ArrayList<>();

        /** This reads data from a file and stores it in the arraylist **/
        try 
        {
            storage = readInput(inputFile);
            System.out.println("Input has been read.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        
        /** This returns the number of occurances of a specified digit **/
        System.out.println("The value " + digit + " occurred " + countIntegerOccurrences(storage, digit) + " times.");


        /** This writes stored data from the arraylist into a file **/
        try 
        {
            writeOutput(outputFile, storage);
            System.out.println("Output has been written.");
            storage.clear();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } 
        
    }

    /**
     * Counts the number of occurrences of a digit in the arraylist
     * @param storage The arraylist to be searched
     * @param digit The digit to be searched for
     * @return The number of occurances of the digit
     */
    private static int countIntegerOccurrences(ArrayList<Integer> storage, int digit) 
    {
        int count = 0;

        for (int i : storage) 
        {
            if (storage.get(i - 1) == digit)
            {
                count++;
            }
        }

        return count;
    }

    /**
     * Reads the input from the file and stores it.
     * @param fileName the provided filename to be opened and read from
     * @throws fileNotFoundException when file can't be found
     */
    public static ArrayList readInput(String fileName) throws FileNotFoundException 
    {
        ArrayList<Integer> temp = new ArrayList<>();

        File myFile = new File(fileName);

        if (!myFile.exists())
        {
            System.out.println("File does not exist.");
            System.exit(0);
        }

        try(Scanner inputFile = new Scanner(myFile)) 
        {
            
            while (inputFile.hasNextLine()) 
            {
                
                String nextLine = inputFile.nextLine();

                int currentInteger = Integer.parseInt(nextLine);

                if (currentInteger > 9 || currentInteger < 0)
                {
                    throw new IllegalArgumentException(currentInteger + " This digit does not work");
                }

                temp.add(currentInteger);

            } 
        

        } catch (FileNotFoundException e) {
            throw new FileNotFoundException("Input file not found.");
        } 


        return temp;

    }

    /**
     * Writes the provided ArrayList to the output file
     * @param fileName The filename of the output file
     * @param storage The ArrayList to be transferred to the output file
     * @throws Exception When file can't be found, security permissions block file from being accessed
     */
    public static void writeOutput(String fileName, ArrayList<Integer> storage) throws Exception
    {
        

        try (PrintWriter myFile = new PrintWriter(fileName)) 
        {
            for (int i : storage) 
            {
                myFile.println(i);
            }
           
            
        } catch (SecurityException | FileNotFoundException e) {
         
            throw new Exception("Output file not found.");
        } 

    }

    public static void printArray(ArrayList<Integer> storage) {
        for (int x : storage) {

            System.out.print(x + "\n");
        }
    }

}
