import java.util.Scanner;
/**
 *
 * @author Alek Kelly
 */


public class GreatestAndLeast
{
    public static void main(String[] args) 
    {
        int largestInteger = 0; //Stores largest Integer
        int smallestInteger = 0; //Stores smallest Integer
        int userInput = 0; //Holds the current user input
        int counter = 0; //Counts the number of inputs


        // Initializes scanner to detect user input
        var scan = new Scanner(System.in);

        // Prompts the user to start entering numbers
        System.out.println("Please enter positive integers one at a time. Type \"-99\" to end the series.");


        //This loops continuously until the user enters -99
        while(1 != 2)
        {
            //Initiates user input 
            userInput = scan.nextInt();

            //If the user enters -99 it triggers the end of the program
            if (userInput == -99)
            {
                //If no numbers have been entered beforehand, this is a special case "if" statement for -99
                if(counter == 0)
                {
                    System.out.println("No numbers were entered.");
                    System.exit(0);
                }


            //Prints the Result
            System.out.println("The largest number entered was: " + largestInteger);
            System.out.println("The smallest number entered was: " + smallestInteger);
            System.exit(0);
            }

            //If the userInput is larger than the current largest integer, replace the largest integer with the current input
            if(userInput > largestInteger)
            {
                largestInteger = userInput;
            }

            //If the userInput is smaller than the current smallest integer, replace the smallest integer with the current 
            if (userInput < smallestInteger)
            {
                smallestInteger = userInput;
            }

            
            scan.close(); //Close scanner for resource purposes
            counter++; //Iterates every loop to detect if -99 entered is the first integer or not, otherwise serves no purpose
        }
        
        

    }

}