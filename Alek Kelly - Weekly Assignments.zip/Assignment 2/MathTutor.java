
//Import necessary for user input
import java.util.Scanner;


/**
 *
 * @author Alek Kelly
 * 
 */

public class MathTutor 
{

    public static void main(String[] args) 
    {
        int userChoice; // Holds the value of 1, 2 or 3
        int problemSolution = 0; // Holds the value of the solution
        int userAnswer = 1; // Holds the value of user answer

        // Initializes scanner to detect user input
        var choice = new Scanner(System.in);

        // This loop will continue to run indefinitely until user inputs a "3" to exit
        // the program.
        while (1 != 2) 
        {
            displayMenu();
            userChoice = choice.nextInt();
            userChoice = checkInput(userChoice, choice);

            // If the user wants an addition or subtraction problem, print them a problem
            // and accept their input
            if (userChoice == 1 || userChoice == 2) 
            {
                problemSolution = displayEquation(userChoice);
                userAnswer = choice.nextInt();
            }

            // Checks to see if their inputted answer is correct or incorrect
            if (userAnswer == problemSolution) 
            {
                System.out.println("Correct.");

            } else {
                System.out.println("Incorrect. The correct answer is " + problemSolution + ".");
            }

        }

    }

    /**
     * Method will check user input and make sure the value is a 1, 2, 3
     * @param userChoice user's input (could be any integer)
     * @param choice     scanner input
     * @return userChoice being a 1 or a 2
     */
    public static int checkInput(int userChoice, Scanner choice) 
    {
        while (userChoice != 1 && userChoice != 2 && userChoice != 3) 
        {
            System.out.println("Sorry, " + userChoice + " is an invalid input.");
            displayMenu();
            userChoice = choice.nextInt();
        }

        if (userChoice == 3) 
        {
            System.out.println("You have selected \"Quit\" and the program has ended");
            choice.close();
            System.exit(0);
        }

        return userChoice;

    }

    /**
     * Method will display the user menu at any called upon point in the code
     */
    public static void displayMenu() 
    {
        System.out.println("Math Tutor");
        System.out.println("    1. Addition Problem");
        System.out.println("    2. Subtraction Problem");
        System.out.println("    3. Quit");
        System.out.println("Enter your choice (1 - 3):");
    }

    /**
     * Method will create, print and store a solution for an addition or subtraction
     * equation
     * @param userChoice The user's input (filtered) being either a 1 or 2
     */
    public static int displayEquation(int userChoice) 
    {

        // These random numbers are generated based on the Math.random() embedded
        // function, but scaled to represent number 0 - 999
        int randomNumber1 = (int) (Math.random() * 1000); // Holds the value of a random number 0 - 999
        int randomNumber2 = (int) (Math.random() * 1000); // Holds the value of a random number 0 - 999

        // Variable to store the solution. Calculated at the end of each print
        int solution = 0;

        // If the userinput is 1 (addition), this prints an addition problem
        if (userChoice == 1) 
        {
            // This will display randomNumber1 on top
            if (randomNumber1 > randomNumber2) 
            {
                // Prints the formatted problem for the user to see
                System.out.printf("%7d%n", randomNumber1);
                System.out.printf("%-1s%6d%n", "+", randomNumber2);
                System.out.println("-------");

                // The order during addition doesn't matter
                solution = randomNumber1 + randomNumber2;
            }
            // This will display randomNumber2 on top
            if (randomNumber1 < randomNumber2) 
            {
                // Prints the formatted problem for the user to see
                System.out.printf("%7d%n", randomNumber2);
                System.out.printf("%-1s%6d%n", "+", randomNumber1);
                System.out.println("-------");

                // The order during addition doesn't matter
                solution = randomNumber1 + randomNumber2;
            }
        }

        // If the user input is 2 (subtraction), this prints a subtraction problem
        if (userChoice == 2) 
        {
            // This will display randomNumber1 on top
            if (randomNumber1 > randomNumber2) 
            {
                // Prints the formatted problem for the user to see
                System.out.printf("%7d%n", randomNumber1);
                System.out.printf("%-1s%6d%n", "-", randomNumber2);
                System.out.println("-------");

                // The order during subtraction does matter
                solution = randomNumber1 - randomNumber2;
            }
            // This will display randomNumber2 on top
            if (randomNumber1 < randomNumber2) 
            {
                // Prints the formatted problem for the user to see
                System.out.printf("%7d%n", randomNumber2);
                System.out.printf("%-1s%6d%n", "-", randomNumber1);
                System.out.println("-------");

                // The order during subtraction does matter
                solution = randomNumber2 - randomNumber1;
            }
        }

        // Returns the solution after printing out the problem
        return solution;

    }

}
