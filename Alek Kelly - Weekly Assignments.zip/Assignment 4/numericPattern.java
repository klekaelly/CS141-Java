//Import for user inputs
import java.util.Scanner;



/**
 *
 * @author Alek Kelly
 * 
 */


public class numericPattern
{
    /** Main Method **/
    public static void main(String[] args) 
    {
        int patternLength = 0; //Holds the user's desired pattern length

        int userChoice; // Holds the value of 1, 2 or 3

        // Initializes scanner to detect user input
        var choice = new Scanner(System.in);

        // This loop will continue to run indefinitely until user inputs a "3" to exit the program.
        while (1 != 2) 
        {
            displayMenu();
            userChoice = choice.nextInt();
            userChoice = checkInput(userChoice, choice);

            // If the user wants an addition or subtraction problem, print them a problem and accept their input
            if (userChoice == 1) 
            {
                patternLength = validateInt("Please enter the size of the pattern. The size must be a positive integer: \n");
                System.out.println(numericPattern(patternLength, true));
            
            }
            if (userChoice == 2)
            {
                patternLength = validateInt("Please enter the size of the pattern. The size must be a positive integer: \n");
                System.out.println(numericPattern(patternLength, false));
            }
            

        }
        

       
      

      
    }



    /** Method validateInt prompts a user for input and checks the input is a positive Integer.
     * @param userChoice is the menu choice of the user (1 - 3)
     * @return returns the user's choice after verifying the input
     */
    public static int checkInput(int userChoice, Scanner choice) 
    {
        while (userChoice != 1 && userChoice != 2 && userChoice != 3) 
        {
            System.out.println("Sorry, " + userChoice + " is an invalid input.");
            displayMenu();
            userChoice = choice.nextInt();
        }

        if (userChoice == 3) 
        {
            System.out.println("You have selected \"Quit\" and the program has ended");
            choice.close();
            System.exit(0);
        }

        return userChoice;

    }

     /** Method validateInt prompts a user for input and checks the input is a positive Integer.
     * @param prompt is the prompt provided to the user
     * @return Returns the user's value ready for use
     */
    public static int validateInt(String prompt)
    {
      int a = 0;       // To hold the user's age
      String str = "";     // Holds the Integer value which is inputted as a string

      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      // Get the user's input.
      boolean again = true;
      
      //Input validation loop
      while(again)
      {
        System.out.print(prompt);
        str = keyboard.nextLine(); // get a string containing an int number
        str = str.trim(); // remove any extra whitespace from string sides
        try    // trying to convert string to integer, expecting exceptions
        {
          a  = Integer.parseInt(str); 
          
         
          again =  false;
          
        }
        catch (Exception e) 
        {
          System.out.println("INPUT ERROR: Please enter an integer number!! Error: "); 
          System.out.print(e.getMessage());
        }
      } 
      
      keyboard.close();
      //Returns the user's values ready to use
     return a;
     
     
    }


   

    /** Method numericPattern takes two parameters, size and direction, and returns a string with a pattern of numbers.
     * @param size is the repeatable size of the pattern
     * @param direction defines the direction of the pattern (reversed or not)
     * @throws IllegalArgumentException when the value is negative or equal to 0
     * @return Returns the string of integers
     */
    public static String numericPattern(int size, boolean direction)
    {

        //throw illegal argument for invalid size parameter
        if(size <= 0)
        {
            throw new IllegalArgumentException();
        }
       

        //Creation of a new string that can be manipulated before returning
        String returnString = "";
        

        //Creates an incrementing string of values (-1 so there is only a single digit in the apex of the turnaround)
        if (direction == true) 
        {

            //Generates the necessary number of incrementing values in the string (1,2,3,4,5....)
            for (int i = 1; i <= size - 1; i++) 
            {
                returnString = returnString + i;
            }

            //Returns the incrementing string with the value of the size in the middle, followed by a call to a method which reverses the string
            returnString = returnString + "" + size + "" + reverseString(returnString);

            
        }

        //Creates a descending string of values
        if (direction == false) 
        {
            //Resets the value of returnString in case for good measure
            returnString = "";

            //Creates a descending string of values that stops at 2
            for (int i = size; i >= 2; i--) 
            {
                returnString = returnString + i;
            }
            
            //Prints the descending value of returnString, prints a 1 in the middle, followed by a call to reverse the string so that it increments
            returnString = returnString + "" + 1 + reverseString(returnString);
           
        }

        return returnString;
        
    }
   
    /** Method reverseString returns the provided string in reverse order 
     * @param numbers is a string that will be reversed
     * @return The reversed string
     */
    public static String reverseString(String numbers)
    {
        String reverse = ""; //Holds reversed string value

        //Creates a new array the size of the string of numbers
        char[] array = new char[numbers.length()];
        int numbersIndex = 0;

        //Iterates and give each index of the array a value in reverse order
        for(int i = numbers.length() - 1; i >= 0; i--) 
        {
            array [numbersIndex] = numbers.charAt(i);
            numbersIndex++;
        }

        //Returns each value of the array to a String
        for (int i = 0; i < numbers.length(); i++)
        {
            reverse = reverse + array[i];
        }

        //Returns the reversed string
        return reverse;
    }


    /**
     * Method will display the user menu at any called upon point in the code
     */
    public static void displayMenu() 
    {
        System.out.println("Numeric Pattern Display");
        System.out.println("    1. Print Type I pattern (like 12321)");
        System.out.println("    2. Print Type II pattern (like 32123)");
        System.out.println("    3. Quit");
        System.out.println("Enter your choice (1 - 3):");
    }
}